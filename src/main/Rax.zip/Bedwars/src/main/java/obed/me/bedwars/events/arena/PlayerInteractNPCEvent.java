package obed.me.bedwars.events.arena;

import lombok.Getter;
import obed.me.bedwars.objects.NPC;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@Getter
public class PlayerInteractNPCEvent extends Event  implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();
    private boolean isCancelled;
    private final Player player;
    private final NPC npc;

    public PlayerInteractNPCEvent(Player player, NPC npc) {
        this.player = player;
        this.npc = npc;
        this.npc.onClick(player.getPlayer());
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    @Override
    public boolean isCancelled() {
        return isCancelled;
    }

    @Override
    public void setCancelled(boolean b) {
        isCancelled  = b;
    }
}

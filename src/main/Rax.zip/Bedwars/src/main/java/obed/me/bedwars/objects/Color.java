package obed.me.bedwars.objects;

import org.bukkit.ChatColor;

import java.util.Locale;

public enum Color {
    ROJO("Rojo", org.bukkit.ChatColor.RED, org.bukkit.Color.RED),
    AZUL("Azul", org.bukkit.ChatColor.DARK_BLUE, org.bukkit.Color.BLUE),
    AMARILLO("Amarillo", org.bukkit.ChatColor.YELLOW, org.bukkit.Color.YELLOW),
    VERDE("Verde", org.bukkit.ChatColor.DARK_GREEN, org.bukkit.Color.GREEN),
    CYAN("Cyan", org.bukkit.ChatColor.DARK_AQUA, org.bukkit.Color.TEAL),
    GRIS("Gris", org.bukkit.ChatColor.GRAY, org.bukkit.Color.GRAY),
    NEGRO("Negro", org.bukkit.ChatColor.BLACK, org.bukkit.Color.BLACK),
    NARANJA("Naranja", org.bukkit.ChatColor.GOLD, org.bukkit.Color.ORANGE),
    ROSA("Rosa", org.bukkit.ChatColor.LIGHT_PURPLE, org.bukkit.Color.FUCHSIA),
    LIMA("Lima", org.bukkit.ChatColor.GREEN, org.bukkit.Color.LIME),
    MORADO("Morado", org.bukkit.ChatColor.DARK_PURPLE, org.bukkit.Color.PURPLE),
    CELESTE("Celeste", org.bukkit.ChatColor.BLUE,org.bukkit.Color.AQUA );
    private final String text;
    private final ChatColor ChatColor;
    private final org.bukkit.Color color;
    Color(String name, ChatColor chatColor, org.bukkit.Color color) {
        this.text = name;
        this.ChatColor = chatColor;
        this.color = color;
    }
    public ChatColor getChatColor(){return ChatColor;}
    public org.bukkit.Color getColor() { return color;}
    public String getName() {
        return text;
    }
    public String getDisplayName(){return this.ChatColor + this.text;}
    public String getIndex(){
        return this.ChatColor + this.text.substring(0,1).toUpperCase(Locale.ROOT);
    }
}

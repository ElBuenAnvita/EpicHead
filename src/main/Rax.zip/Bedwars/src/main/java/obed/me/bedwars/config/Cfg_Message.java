package obed.me.bedwars.config;

public class Cfg_Message {
}

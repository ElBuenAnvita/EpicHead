package obed.me.bedwars.bungee;

public class BungeeMain {
}

package obed.me.bedwars.objects.shop;

import lombok.Getter;
import lombok.Setter;
import obed.me.bedwars.objects.game.Team;
import org.bukkit.Location;
import obed.me.bedwars.objects.NPC;
@Getter
@Setter
public class Shop {
    private Team team;
    private NPC NPC;
    private Location Location;
    private ShopInventory shopInventory;
}

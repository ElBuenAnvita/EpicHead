package obed.me.bedwars.store;

public class Database {
}

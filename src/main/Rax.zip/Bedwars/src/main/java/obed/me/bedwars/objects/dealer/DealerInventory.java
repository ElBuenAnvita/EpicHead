package obed.me.bedwars.objects.dealer;

import net.minecraft.server.v1_8_R3.NBTTagCompound;
import obed.me.bedwars.Bedwars;
import obed.me.bedwars.config.Cfg_Dealer;
import obed.me.bedwars.events.shop.CancelledDealerReason;
import obed.me.bedwars.events.shop.Result;
import obed.me.bedwars.events.shop.UserBuyDealerEvent;
import obed.me.bedwars.objects.SpawnerType;
import obed.me.bedwars.objects.game.Team;
import obed.me.bedwars.objects.game.User;
import obed.me.bedwars.objects.shop.CustomInventory;
import obed.me.bedwars.objects.shop.TypeInventory;
import obed.me.bedwars.utils.Colorize;
import obed.me.bedwars.utils.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import team.unnamed.gui.api.item.Button;
import team.unnamed.gui.api.item.DefaultItemClickable;
import team.unnamed.gui.menu.MenuBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class DealerInventory extends CustomInventory {
    private final Cfg_Dealer cf = Bedwars.getInstance().getCfgDealer();
    private final List<String> lore = new ArrayList<>(Collections.singletonList("&7↓ Trampas en cola."));
    private final ItemStack panel = ItemUtil.createItem("&7↑ Adquirible.", lore,160, (short) 8,1);
    private final Button bpanel = a->{
        a.setCancelled(true);
        return true;
    };
    @Override
    public void openInventory(Player p) {
        MenuBuilder menu = MenuBuilder.newBuilder(Colorize.toColor(cf.getConfig().getString("title")),
                cf.getConfig().getInt("size")/9);
        User user = User.getUser(p);
        Team team = user.getTeam();
        for(String identifier : cf.getConfig().getConfigurationSection("dealers").getKeys(false)){
            ConfigurationSection id_cf = cf.getConfig().getConfigurationSection("dealers." + identifier);
            DItem dItem = new DItem(identifier);
            dItem.setSlot(id_cf.getInt("slot"));
            int material = Integer.parseInt(id_cf.getString("icon").split(":")[0]);
            short data = Short.parseShort(id_cf.getString("icon").split(":")[1]);
            dItem.setMax_lvl(id_cf.getConfigurationSection("leveling").getKeys(false).size());
            //leveling:
            int lvl = 1;
            dItem.setLevel(lvl);
            if(team.getDealer().containsDealer(dItem) != null) {
                if(team.getDealer().containsDealer(dItem).getLevel()+1 <= dItem.getMax_lvl()){
                    lvl = team.getDealer().containsDealer(dItem).getLevel() + 1;
                    dItem.setLevel(lvl);
                }
            }
            if(dItem.isLeveling()){
                ConfigurationSection leveling = id_cf.getConfigurationSection("leveling." + lvl);
                dItem.setEnchLevel(leveling.getDouble("enchant_lvl"));
                dItem.setIndex(leveling.getString("index"));
                dItem.setAmount(leveling.getInt("price.amount"));
                dItem.setSpawnerType(SpawnerType.valueOf(leveling.getString("price.type").toUpperCase(Locale.ROOT)));
            } else {
                dItem.setIndex("I");
                dItem.setEnchLevel(id_cf.getDouble("enchant_lvl"));
                dItem.setAmount(id_cf.getInt("price.amount"));
                dItem.setSpawnerType(SpawnerType.valueOf(id_cf.getString("price.type").toUpperCase(Locale.ROOT)));

            }

            String name = Colorize.toColor(id_cf.getName().replaceAll("%index%", dItem.getIndex()));
            List<String> lore = new ArrayList<>();
            for(String str : id_cf.getStringList("lore")){
                lore.add(str.replaceAll("%price%", dItem.getAmount()+"")
                        .replaceAll("%type%", dItem.getDealerType().toString())
                        .replaceAll("%index%", dItem.getIndex()));
            }
            dItem.setIcon(ItemUtil.createItem(name, Colorize.toColor(lore), Material.getMaterial(material), data));
            dItem.setDealerItemType(DealerItemType.valueOf(id_cf.getString("type").toUpperCase(Locale.ROOT)));
            dItem.setDealerType(DealerType.DEALER);
            Button button = getBuyOption(dItem);
            DefaultItemClickable clickable = new DefaultItemClickable(dItem.getSlot(), dItem.getIcon(), button);
            menu.addItem(clickable);
        }
        Inventory inventory = menu.build();
        p.openInventory(inventory);
        p.playSound(p.getLocation(), Sound.NOTE_BASS, 5F,5F);
    }

    private Button getBuyOption(DItem dItem) {
        return a ->{
            a.setCancelled(true);
            Player p = (Player) a.getWhoClicked();
            User user = User.getUser(p);
            Team team = user.getTeam();
            UserBuyDealerEvent userBuyDealerEvent = new UserBuyDealerEvent(user,team,dItem);
            if(!hasAmount(p,dItem)){
                userBuyDealerEvent.setCancelled(true);
                userBuyDealerEvent.setReason(CancelledDealerReason.NOT_ENOUGH_ITEMS);
                Bukkit.getPluginManager().callEvent(userBuyDealerEvent);
                //No tiene materiales suficientes.
                return true;
            }
            if(dItem.isMaxLevel()){
                userBuyDealerEvent.setCancelled(true);
                userBuyDealerEvent.setReason(CancelledDealerReason.MAX_LEVEL);
                Bukkit.getPluginManager().callEvent(userBuyDealerEvent);
                //Es el mayor nivel, no se puede comprar.
                return true;
            }
            if(dItem.isLeveling() && team.getDealers().containsKey(dItem.getIdentifier())){
                userBuyDealerEvent.setCancelled(true);
                userBuyDealerEvent.setReason(CancelledDealerReason.BOUGHT);
                Bukkit.getPluginManager().callEvent(userBuyDealerEvent);
                //ya lo  compró
                return true;
            }
            if(dItem.getDealerType() == DealerType.TRAP){
                if(team.getTraps().containsKey(dItem.getIdentifier())){
                    userBuyDealerEvent.setCancelled(true);
                    userBuyDealerEvent.setReason(CancelledDealerReason.BOUGHT);
                    Bukkit.getPluginManager().callEvent(userBuyDealerEvent);
                    //ya compró la trampa.
                    return true;
                }
                if(team.getTraps().size() == 3){
                    userBuyDealerEvent.setCancelled(true);
                    userBuyDealerEvent.setReason(CancelledDealerReason.NOT_ENOUGH_SPACE);
                    Bukkit.getPluginManager().callEvent(userBuyDealerEvent);
                    //maxima cantidad de trampas activas.
                    return true;
                }
            }
            userBuyDealerEvent.setCancelled(false);
            Bukkit.getPluginManager().callEvent(userBuyDealerEvent);
            //puede comprar.
            return true;
        };
    }


    private boolean hasAmount(Player p , DItem item) {
        Material material = item.getSpawnerType().getDroptype();;
        int amount = item.getAmount();
        int count = 0;
        for(ItemStack itm : p.getInventory().getContents()){
            if(itm == null) continue;
            if(itm.getType() == Material.AIR) continue;
            if(itm.getType() == material)
                count+=itm.getAmount();
        }
        return count >= amount;
    }

    @Override
    public void loadInventoryData() {

    }

    @Override
    public TypeInventory getType() {
        return TypeInventory.DEALER;
    }
}

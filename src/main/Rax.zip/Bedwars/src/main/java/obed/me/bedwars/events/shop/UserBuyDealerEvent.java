package obed.me.bedwars.events.shop;


import lombok.Getter;
import lombok.Setter;
import obed.me.bedwars.objects.dealer.DItem;
import obed.me.bedwars.objects.game.Team;
import obed.me.bedwars.objects.game.User;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@Getter
@Setter
public class UserBuyDealerEvent extends Event implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private boolean cancelled;
    private User user;
    private Team team;
    private CancelledDealerReason reason;
    private DItem dItem;
    public HandlerList getHandlers(){
        return handlers;
    }
    public static HandlerList getHandlerList() {
        return handlers;
    }

    public UserBuyDealerEvent(User user, Team team, DItem DItem){
        this.user = user;
        this.team = team;
        this.dItem = DItem;

    }
    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean b) {
        cancelled = b;
    }

}

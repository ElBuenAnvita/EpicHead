package obed.me.bedwars.utils;

import obed.me.bedwars.objects.shop.SItem;

import java.util.Comparator;

public class ComparatorUtil implements Comparator<SItem> {

    @Override
    public int compare(SItem s1, SItem s2) {
        return Integer.compare(s1.getLevel(), s2.getLevel());
    }
}

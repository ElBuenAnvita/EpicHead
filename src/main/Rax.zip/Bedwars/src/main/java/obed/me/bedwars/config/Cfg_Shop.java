package obed.me.bedwars.config;

import obed.me.bedwars.Bedwars;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

public class Cfg_Shop extends CfgManager{
    /**
     * Method that return the config object
     * @return FileConfiguration
     */
    @Override
    public FileConfiguration getConfig() {
        if (this.config == null)
            reloadConfig();
        return this.config;
    }
    /**
     * Public method to reload the config.yml file
     */
    @Override
    public void reloadConfig() {
        if (this.config == null) {
            String path = plugin.getDataFolder().getPath()+ "/";
            this.configFile =  new File(path + "shop" + ".yml");
        }
        this.config = YamlConfiguration.loadConfiguration(this.configFile);
        Reader defConfigStream = new InputStreamReader(this.plugin.getResource( "shop" + ".yml"), StandardCharsets.UTF_8);
        YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(defConfigStream);
        this.config.setDefaults(defConfig);
    }


    /**
     * Register a new Config.yml File
     */
    @Override
    public void registerConfig() {
        plugin = Bedwars.getInstance();
        String path = plugin.getDataFolder().getPath()+ "/";

        configFile = new File(path  + "shop" + ".yml");
        if(!configFile.exists()){
            try {
                configFile.createNewFile();
                config = YamlConfiguration.loadConfiguration(configFile);
                Reader defConfigStream = new InputStreamReader(this.plugin.getResource("shop" + ".yml"), StandardCharsets.UTF_8);
                YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(defConfigStream);
                config.setDefaults(defConfig);
                config.options().copyDefaults(true);
                config.save(configFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

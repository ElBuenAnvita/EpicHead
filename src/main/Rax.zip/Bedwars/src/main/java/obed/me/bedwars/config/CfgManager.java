package obed.me.bedwars.config;

import obed.me.bedwars.Bedwars;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.io.IOException;

public abstract class CfgManager {
    protected Bedwars plugin = Bedwars.getInstance();
    protected File configFile;
    protected FileConfiguration config;

    public abstract FileConfiguration getConfig();
    public abstract void reloadConfig();

    public void saveConfig(){
        try {
            this.config.save(this.configFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public abstract void registerConfig();
}

package obed.me.bedwars.events.npc;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.*;
import obed.me.bedwars.Bedwars;
import obed.me.bedwars.events.arena.PlayerInteractNPCEvent;
import obed.me.bedwars.managers.NPCManager;
import obed.me.bedwars.objects.NPC;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class HandlerNPC extends PacketAdapter {
    private static final List<Player> playerclicks = new ArrayList<>();
    public HandlerNPC(Bedwars bedwars, ListenerPriority normal, PacketType useEntity) {
        super(bedwars,normal,useEntity);
    }
    @Override
    public void onPacketReceiving(PacketEvent event) {
        if(event.getPacketType() == PacketType.Play.Client.USE_ENTITY){
            try {
                PacketContainer packet = event.getPacket();
                int id = packet.getIntegers().read(0);
                NPC npc = NPCManager.getNPC(id);
                if(npc != null){
                    if(playerclicks.contains(event.getPlayer()))
                        return;
                    PlayerInteractNPCEvent interact = new PlayerInteractNPCEvent(event.getPlayer(), npc);
                    Bukkit.getPluginManager().callEvent(interact);
                    playerclicks.add(event.getPlayer());
                    Bukkit.getScheduler().runTaskLaterAsynchronously(Bedwars.getInstance(), ()-> playerclicks.remove(event.getPlayer()),2L);
                }

            } catch (Exception ignored){}
        }
    }

}

package obed.me.bedwars.utils.nms;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public interface INMS {
    void HideArmor(Player p, int value, ItemStack item);
    void sendPacket(Player p, Object packet);
    Class<?> getNMSClass(String name);
    Object getCraftItem(ItemStack itemStack);
    Class<?> getBukkitClass(String name);
}

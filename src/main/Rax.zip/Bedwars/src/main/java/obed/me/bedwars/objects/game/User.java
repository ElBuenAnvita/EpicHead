package obed.me.bedwars.objects.game;

import lombok.Getter;
import lombok.Setter;
import obed.me.bedwars.objects.shop.SItem;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.*;

@Getter
@Setter
public class User {
    private final Player player;
    private Team team;
    private int level, bedDestroyed,kills,finalkills,deaths;
    private Inventory customShop;
    private Entity Dealer;
    private Entity Shop;
    private Inventory ShopInventory;
    private boolean Spectator;
    private SItem quickItem;
    private static HashMap<Player, User> users = new HashMap<>();
    private Set<SItem> quickShop = new HashSet<>();
    private HashMap<SItem, List<SItem>> buyedItems = new HashMap<>();


    public User(Player player) {
        this.player = player;
        users.put(player, this);
    }

    public static User getUser(Player target) {
        if(users.containsKey(target)){
            return users.get(target);
        }
        return new User(target);
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    
    /*
    TODO:
    //save into the database when a player left o the server shut down
    //load the global data only in the lobby
    //load the cosmetics like chat, animations, etc. maybe in other class or plugin

        .
     */

}

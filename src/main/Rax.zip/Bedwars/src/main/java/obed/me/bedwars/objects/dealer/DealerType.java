package obed.me.bedwars.objects.dealer;

public enum DealerType {
    TRAP, DEALER
}

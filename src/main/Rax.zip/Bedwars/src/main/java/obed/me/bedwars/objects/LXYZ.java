package obed.me.bedwars.objects;

import obed.me.bedwars.objects.game.Team;
import org.bukkit.Location;
import org.bukkit.block.BlockFace;

import java.util.Arrays;
import java.util.List;

public class LXYZ {
    private Team team;
    private Location cor1;
    private Location cor2;
    private static final List<BlockFace> blockFaceList = Arrays.asList(BlockFace.NORTH,BlockFace.SOUTH,BlockFace.EAST, BlockFace.WEST);
    public LXYZ(Team team){
        this.team = team;
    }

    public static List<BlockFace> getBlockFaceList() {
        return blockFaceList;
    }

    public Location getCor1() {
        return cor1;
    }

    public void setCor1(Location cor1) {
        this.cor1 = cor1;
    }

    public Location getCor2() {
        return cor2;
    }

    public void setCor2(Location cor2) {
        this.cor2 = cor2;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
}

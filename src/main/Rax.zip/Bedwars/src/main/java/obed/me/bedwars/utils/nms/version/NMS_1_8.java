package obed.me.bedwars.utils.nms.version;

import obed.me.bedwars.utils.nms.NMS;
import obed.me.bedwars.utils.reflect.ReflectConstructor;
import obed.me.bedwars.utils.reflect.ReflectField;
import obed.me.bedwars.utils.reflect.ReflectMethod;
import obed.me.bedwars.utils.reflect.ReflectionUtil;
import org.apache.commons.lang.Validate;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
public class NMS_1_8 extends NMS {
    private static final Class<?> ENTITY_CLASS = ReflectionUtil.getNMSClass("Entity");

    private static final Class<?> ITEM_STACK_CLASS = ReflectionUtil.getNMSClass("ItemStack");

    private static final ReflectMethod CRAFT_ITEM_NMS_COPY_METHOD = new ReflectMethod(ReflectionUtil.getObcClass("inventory.CraftItemStack"), "asNMSCopy", new Class[] { ItemStack.class });

    private static final Class<?> DATA_WATCHER_CLASS = ReflectionUtil.getNMSClass("DataWatcher");

    private static final ReflectConstructor DATA_WATCHER_CONSTRUCTOR = new ReflectConstructor(DATA_WATCHER_CLASS, new Class[] { ENTITY_CLASS });

    private static final ReflectMethod DATA_WATCHER_A_METHOD = new ReflectMethod(DATA_WATCHER_CLASS, "a", new Class[] { int.class, Object.class });

    private static final Class<?> MATH_HELPER_CLASS = ReflectionUtil.getNMSClass("MathHelper");

    private static final ReflectMethod MATH_HELPER_FLOOR_METHOD = new ReflectMethod(MATH_HELPER_CLASS, "floor", new Class[] { double.class });

    private static final ReflectMethod MATH_HELPER_D_METHOD = new ReflectMethod(MATH_HELPER_CLASS, "d", new Class[] { float.class });

    private static final ReflectConstructor PACKET_SPAWN_ENTITY_CONSTRUCTOR = new ReflectConstructor(ReflectionUtil.getNMSClass("PacketPlayOutSpawnEntity"), new Class[0]);

    private static final ReflectConstructor PACKET_SPAWN_ENTITY_LIVING_CONSTRUCTOR = new ReflectConstructor(ReflectionUtil.getNMSClass("PacketPlayOutSpawnEntityLiving"), new Class[0]);

    private static final ReflectConstructor PACKET_ENTITY_METADATA_CONSTRUCTOR = new ReflectConstructor(ReflectionUtil.getNMSClass("PacketPlayOutEntityMetadata"), new Class[] { int.class, DATA_WATCHER_CLASS, boolean.class });

    private static final ReflectConstructor PACKET_ENTITY_TELEPORT_CONSTRUCTOR = new ReflectConstructor(ReflectionUtil.getNMSClass("PacketPlayOutEntityTeleport"), new Class[0]);

    private static final ReflectConstructor PACKET_ATTACH_ENTITY_CONSTRUCTOR = new ReflectConstructor(ReflectionUtil.getNMSClass("PacketPlayOutAttachEntity"), new Class[0]);

    private static final ReflectConstructor PACKET_ENTITY_EQUIPMENT_CONSTRUCTOR = new ReflectConstructor(ReflectionUtil.getNMSClass("PacketPlayOutEntityEquipment"), new Class[] { int.class, int.class, ITEM_STACK_CLASS });

    private static final ReflectConstructor PACKET_ENTITY_DESTROY_CONSTRUCTOR = new ReflectConstructor(ReflectionUtil.getNMSClass("PacketPlayOutEntityDestroy"), new Class[] { int[].class });

    private static final ReflectField<?> ENTITY_COUNTER_FIELD = new ReflectField(ENTITY_CLASS, "entityCount");

    public int getFreeEntityId() {
        int entityCount = Integer.parseInt((String)ENTITY_COUNTER_FIELD.getValue(null));
        ENTITY_COUNTER_FIELD.setValue(null, Integer.valueOf(entityCount + 1));
        return entityCount;
    }

    public void showFakeEntity(Player player, Location location, EntityType entityType, int entityId) {
        Validate.notNull(entityType);
        showFakeEntity(player, location, getEntityTypeId(entityType), entityId);
    }

    public void showFakeEntityLiving(Player player, Location location, EntityType entityType, int entityId) {
        Object dataWatcher = DATA_WATCHER_CONSTRUCTOR.newInstance(new Object[] { ENTITY_CLASS.cast(null) });
        DATA_WATCHER_A_METHOD.invoke(dataWatcher, new Object[] { Integer.valueOf(15), Byte.valueOf((byte)0) });
        showFakeEntityLiving(player, location, getEntityTypeId(entityType), entityId, dataWatcher);
    }

    public void showFakeEntityArmorStand(Player player, Location location, int entityId, boolean invisible, boolean small, boolean clickable) {
        Object dataWatcher = DATA_WATCHER_CONSTRUCTOR.newInstance(new Object[] { ENTITY_CLASS.cast(null) });
        DATA_WATCHER_A_METHOD.invoke(dataWatcher, new Object[] { Integer.valueOf(0), Byte.valueOf((byte)(invisible ? 32 : 0)) });
        byte data = 8;
        if (small)
            data = (byte)(data + 1);
        if (!clickable)
            data = (byte)(data + 16);
        DATA_WATCHER_A_METHOD.invoke(dataWatcher, new Object[] { Integer.valueOf(10), Byte.valueOf(data) });
        showFakeEntityLiving(player, location, 30, entityId, dataWatcher);
    }

    public void showFakeEntityItem(Player player, Location location, ItemStack itemStack, int entityId) {
        Validate.notNull(player);
        Validate.notNull(location);
        Validate.notNull(itemStack);
        Object nmsItemStack = CRAFT_ITEM_NMS_COPY_METHOD.invokeStatic(new Object[] { itemStack });
        Object dataWatcher = DATA_WATCHER_CONSTRUCTOR.newInstance(new Object[] { ENTITY_CLASS.cast(null) });
        if (nmsItemStack == null || dataWatcher == null)
            return;
        DATA_WATCHER_A_METHOD.invoke(dataWatcher, new Object[] { Integer.valueOf(10), nmsItemStack });
        showFakeEntity(player, location, 2, entityId);
        sendPacket(player, PACKET_ENTITY_METADATA_CONSTRUCTOR.newInstance(new Object[] { Integer.valueOf(entityId), dataWatcher, Boolean.valueOf(true) }));
        teleportFakeEntity(player, location, entityId);
    }

    public void updateFakeEntityCustomName(Player player, String name, int entityId) {
        Validate.notNull(player);
        Validate.notNull(name);
        Object dataWatcher = DATA_WATCHER_CONSTRUCTOR.newInstance(new Object[] { ENTITY_CLASS.cast(null) });
        DATA_WATCHER_A_METHOD.invoke(dataWatcher, new Object[] { Integer.valueOf(2), name });
        DATA_WATCHER_A_METHOD.invoke(dataWatcher, new Object[] { Integer.valueOf(3), Byte.valueOf((byte)(ChatColor.stripColor(name).isEmpty() ? 0 : 1)) });
        sendPacket(player, PACKET_ENTITY_METADATA_CONSTRUCTOR.newInstance(new Object[] { Integer.valueOf(entityId), dataWatcher, Boolean.valueOf(true) }));
    }

    public void teleportFakeEntity(Player player, Location location, int entityId) {
        Validate.notNull(player);
        Validate.notNull(location);
        Object teleport = PACKET_ENTITY_TELEPORT_CONSTRUCTOR.newInstance(new Object[0]);
        if (teleport == null)
            return;
        ReflectionUtil.setFieldValue(teleport, "a", Integer.valueOf(entityId));
        ReflectionUtil.setFieldValue(teleport, "b", MATH_HELPER_FLOOR_METHOD.invokeStatic(new Object[] { Double.valueOf(location.getX() * 32.0D) }));
        ReflectionUtil.setFieldValue(teleport, "c", MATH_HELPER_FLOOR_METHOD.invokeStatic(new Object[] { Double.valueOf(location.getY() * 32.0D) }));
        ReflectionUtil.setFieldValue(teleport, "d", MATH_HELPER_FLOOR_METHOD.invokeStatic(new Object[] { Double.valueOf(location.getZ() * 32.0D) }));
        ReflectionUtil.setFieldValue(teleport, "e", Byte.valueOf((byte)(int)(location.getYaw() * 256.0F / 360.0F)));
        ReflectionUtil.setFieldValue(teleport, "f", Byte.valueOf((byte)(int)(location.getPitch() * 256.0F / 360.0F)));
        ReflectionUtil.setFieldValue(teleport, "g", Boolean.valueOf(true));
        sendPacket(player, teleport);
    }

    public void helmetFakeEntity(Player player, ItemStack itemStack, int entityId) {
        Validate.notNull(player);
        Validate.notNull(itemStack);
        Object nmsItemStack = CRAFT_ITEM_NMS_COPY_METHOD.invokeStatic(new Object[] { itemStack });
        if (nmsItemStack == null)
            return;
        Object packet = PACKET_ENTITY_EQUIPMENT_CONSTRUCTOR.newInstance(new Object[] { Integer.valueOf(entityId), Integer.valueOf(4), nmsItemStack });
        if (packet == null)
            return;
        sendPacket(player, packet);
    }

    public void attachFakeEnity(Player player, int vehicleId, int entityId) {
        Validate.notNull(player);
        Object packet = PACKET_ATTACH_ENTITY_CONSTRUCTOR.newInstance(new Object[0]);
        if (packet == null)
            return;
        ReflectionUtil.setFieldValue(packet, "a", Integer.valueOf(0));
        ReflectionUtil.setFieldValue(packet, "b", Integer.valueOf(entityId));
        ReflectionUtil.setFieldValue(packet, "c", Integer.valueOf(vehicleId));
        sendPacket(player, packet);
    }

    public void hideFakeEntities(Player player, int... entityIds) {
        Validate.notNull(player);
        sendPacket(player, PACKET_ENTITY_DESTROY_CONSTRUCTOR.newInstance(new Object[] { entityIds }));
    }

    public void showFakeEntity(Player player, Location location, int entityTypeId, int entityId) {
        Validate.notNull(player);
        Validate.notNull(location);
        Object spawn = PACKET_SPAWN_ENTITY_CONSTRUCTOR.newInstance(new Object[0]);
        if (spawn == null)
            return;
        ReflectionUtil.setFieldValue(spawn, "a", Integer.valueOf(entityId));
        ReflectionUtil.setFieldValue(spawn, "b", MATH_HELPER_FLOOR_METHOD.invokeStatic(new Object[] { Double.valueOf(location.getX() * 32.0D) }));
        ReflectionUtil.setFieldValue(spawn, "c", MATH_HELPER_FLOOR_METHOD.invokeStatic(new Object[] { Double.valueOf(location.getY() * 32.0D) }));
        ReflectionUtil.setFieldValue(spawn, "d", MATH_HELPER_FLOOR_METHOD.invokeStatic(new Object[] { Double.valueOf(location.getZ() * 32.0D) }));
        ReflectionUtil.setFieldValue(spawn, "h", MATH_HELPER_D_METHOD.invokeStatic(new Object[] { Float.valueOf(location.getPitch() * 256.0F / 360.0F) }));
        ReflectionUtil.setFieldValue(spawn, "i", MATH_HELPER_D_METHOD.invokeStatic(new Object[] { Float.valueOf(location.getYaw() * 256.0F / 360.0F) }));
        ReflectionUtil.setFieldValue(spawn, "j", Integer.valueOf(entityTypeId));
        sendPacket(player, spawn);
    }

    private void showFakeEntityLiving(Player player, Location location, int entityTypeId, int entityId, Object dataWatcher) {
        Validate.notNull(player);
        Validate.notNull(location);
        if (dataWatcher == null || !DATA_WATCHER_CLASS.isAssignableFrom(dataWatcher.getClass()))
            return;
        Object spawn = PACKET_SPAWN_ENTITY_LIVING_CONSTRUCTOR.newInstance(new Object[0]);
        if (spawn == null)
            return;
        ReflectionUtil.setFieldValue(spawn, "a", Integer.valueOf(entityId));
        ReflectionUtil.setFieldValue(spawn, "b", Integer.valueOf(entityTypeId));
        ReflectionUtil.setFieldValue(spawn, "c", MATH_HELPER_FLOOR_METHOD.invokeStatic(new Object[] { Double.valueOf(location.getX() * 32.0D) }));
        ReflectionUtil.setFieldValue(spawn, "d", MATH_HELPER_FLOOR_METHOD.invokeStatic(new Object[] { Double.valueOf(location.getY() * 32.0D) }));
        ReflectionUtil.setFieldValue(spawn, "e", MATH_HELPER_FLOOR_METHOD.invokeStatic(new Object[] { Double.valueOf(location.getZ() * 32.0D) }));
        ReflectionUtil.setFieldValue(spawn, "i", Byte.valueOf((byte)(int)(location.getYaw() * 256.0F / 360.0F)));
        ReflectionUtil.setFieldValue(spawn, "j", Byte.valueOf((byte)(int)(location.getPitch() * 256.0F / 360.0F)));
        ReflectionUtil.setFieldValue(spawn, "k", Byte.valueOf((byte)(int)(location.getYaw() * 256.0F / 360.0F)));
        ReflectionUtil.setFieldValue(spawn, "l", dataWatcher);
        sendPacket(player, spawn);
    }

    public void showFakeEntityGiant(Player player, Location location, int entityId, boolean invisible, boolean clickable, ItemStack itemStack) {
        Object dataWatcher = DATA_WATCHER_CONSTRUCTOR.newInstance(new Object[] { ENTITY_CLASS.cast(null) });
        DATA_WATCHER_A_METHOD.invoke(dataWatcher, new Object[] { Integer.valueOf(0), Byte.valueOf((byte)(invisible ? 32 : 0)) });
        byte data = 8;
        if (!clickable)
            data = (byte)(data + 16);
        DATA_WATCHER_A_METHOD.invoke(dataWatcher, new Object[] { Integer.valueOf(10), Byte.valueOf(data) });
        showFakeEntityLiving(player, location, getEntityTypeId(EntityType.GIANT), entityId, dataWatcher);
        giantItem(player, itemStack, entityId);
    }

    private void giantItem(Player player, ItemStack itemStack, int entityId) {
        Validate.notNull(player);
        Validate.notNull(itemStack);
        Object nmsItemStack = CRAFT_ITEM_NMS_COPY_METHOD.invokeStatic(new Object[] { itemStack });
        if (nmsItemStack == null)
            return;
        Object packet = PACKET_ENTITY_EQUIPMENT_CONSTRUCTOR.newInstance(new Object[] { Integer.valueOf(entityId), Integer.valueOf(0), nmsItemStack });
        if (packet == null)
            return;
        sendPacket(player, packet);
    }
}
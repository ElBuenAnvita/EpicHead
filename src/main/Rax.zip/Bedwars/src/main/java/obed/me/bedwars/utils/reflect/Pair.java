package obed.me.bedwars.utils.reflect;

public class Pair<K, V> {
    private K key;

    private V value;

    public void setKey(K key) {
        this.key = key;
    }

    public void setValue(V value) {
        this.value = value;
    }

    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Pair))
            return false;
        Pair<?, ?> other = (Pair<?, ?>)o;
        if (!other.canEqual(this))
            return false;
        Object this$key = getKey(), other$key = other.getKey();
        if ((this$key == null) ? (other$key != null) : !this$key.equals(other$key))
            return false;
        Object this$value = getValue(), other$value = other.getValue();
        return !((this$value == null) ? (other$value != null) : !this$value.equals(other$value));
    }

    protected boolean canEqual(Object other) {
        return other instanceof Pair;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $key = getKey();
        result = result * 59 + (($key == null) ? 43 : $key.hashCode());
        Object $value = getValue();
        return result * 59 + (($value == null) ? 43 : $value.hashCode());
    }

    public String toString() {
        return "Pair(key=" + getKey() + ", value=" + getValue() + ")";
    }

    public Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey() {
        return this.key;
    }

    public V getValue() {
        return this.value;
    }
}
package obed.me.bedwars.objects.dealer;

import lombok.Getter;
import lombok.Setter;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.minecraft.server.v1_8_R3.NBTTagString;
import obed.me.bedwars.objects.SpawnerType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
@Getter
@Setter
public class DItem {
    private ItemStack icon;
    private String identifier;
    private List<PotionEffect> effects_enemies = new ArrayList<>();
    private List<PotionEffect> effects_team = new ArrayList<>();
    private DealerItemType dealerItemType;
    private int max_lvl;
    private double EnchLevel;
    private boolean leveling;
    private int level;
    private DealerType dealerType;
    private String index;
    private SpawnerType spawnerType;
    private int amount;
    private int slot;
    private static HashMap<String, DItem> DItemList = new HashMap<>();
    public DItem(String identifier){
        this.identifier = identifier;
        DItemList.put(this.identifier, this);
    }

    public boolean isMaxLevel() {
        return level == max_lvl;
    }
}

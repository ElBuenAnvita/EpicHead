package obed.me.bedwars.objects.game;

import lombok.Getter;
import lombok.Setter;
import obed.me.bedwars.Bedwars;
import obed.me.bedwars.objects.Color;
import obed.me.bedwars.objects.LXYZ;
import obed.me.bedwars.objects.Spawner;
import obed.me.bedwars.objects.ZoneCuboid;
import obed.me.bedwars.objects.dealer.DItem;
import obed.me.bedwars.objects.dealer.Dealer;
import obed.me.bedwars.objects.shop.Shop;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

@Setter
@Getter
public class Team {
    private final Set<User> Players = new HashSet<>();
    private final Set<String> namedPlayers = new HashSet<>();
    private Color color;
    private LXYZ bed;
    private Location spawn;
    private Chest team_chest;
    private boolean BedDestroy;
    private int maxInTeam;
    private String name;
    private Dealer dealer;
    private Shop shop;
    private Location shop_location;
    private Location dealer_location;
    private ZoneCuboid island;
    private int dragons;
    private final ArrayList<Spawner> spawners = new ArrayList<>();
    private final HashMap<String , DItem> dealers = new HashMap<>();
    private final HashMap<String, DItem> traps = new HashMap<>();

    public Team(String name) {
        this.name = name;
        this.color = Color.valueOf(name.toUpperCase(Locale.ROOT));
    }

}

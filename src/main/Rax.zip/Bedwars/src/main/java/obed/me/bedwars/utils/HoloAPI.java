package obed.me.bedwars.utils;

import obed.me.bedwars.objects.Hologram;
import org.bukkit.Location;

import java.util.HashMap;

public class HoloAPI {
    private static final HashMap<String, Hologram> hologramHashMap = new HashMap<>();


    public static void createHologram(String key, Location loc, String name){
        hologramHashMap.remove(key);
     //   hologramHashMap.put(key, new Hologram(key, loc, name));
    }

    public static Hologram getHologram(String key){
        if(!hologramHashMap.containsKey(key))
            return null;
        return hologramHashMap.get(key);
    }


}

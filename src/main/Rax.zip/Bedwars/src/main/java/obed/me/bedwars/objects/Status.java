package obed.me.bedwars.objects;

public enum Status {
    GAME("En Juego"),
    WAITING("Esperando"),
    FINISH("Reiniciando");
    private String text;

    Status(String str) {
        this.text = str;
    }

    public String getText() {
        return text;
    }
}

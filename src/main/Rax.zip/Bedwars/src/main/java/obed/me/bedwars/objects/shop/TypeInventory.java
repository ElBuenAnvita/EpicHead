package obed.me.bedwars.objects.shop;

public enum TypeInventory {
    SHOP,DEALER,GAME,PLAYERS,FIND_PLAYER
}

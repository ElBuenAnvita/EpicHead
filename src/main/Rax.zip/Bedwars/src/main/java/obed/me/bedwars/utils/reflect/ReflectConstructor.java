package obed.me.bedwars.utils.reflect;

import java.lang.reflect.Constructor;

public class ReflectConstructor {
    private final Class<?> clazz;

    private final Class<?>[] parameterTypes;

    private Constructor<?> constructor;

    public ReflectConstructor(Class<?> clazz, Class<?>... parameterTypes) {
        this.clazz = clazz;
        this.parameterTypes = parameterTypes;
    }

    private void init() {
        if (this.constructor != null)
            return;
        try {
            this.constructor = this.clazz.getDeclaredConstructor(this.parameterTypes);
            this.constructor.setAccessible(true);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
    }

    public <T> T newInstance(Object... args) {
        init();
        Object object = null;
        try {
            object = this.constructor.newInstance(args);
        } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException|InstantiationException e) {
            e.printStackTrace();
        }
        return (object == null) ? null : (T)object;
    }
}
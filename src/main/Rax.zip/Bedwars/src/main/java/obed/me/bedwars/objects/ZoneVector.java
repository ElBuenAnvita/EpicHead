package obed.me.bedwars.objects;

import lombok.Getter;
import lombok.Setter;
import org.bukkit.Location;
import org.bukkit.World;

@Getter
@Setter
public class ZoneVector {
    private int x;
    private int y;
    private int z;
    public ZoneVector(int x, int y, int z){
        this.x = x;
        this.z = z;
        this.y = y;
    }

    public ZoneVector(Location location){
        this.x = location.getBlockX();
        this.z = location.getBlockY();
        this.y = location.getBlockZ();
    }
    public boolean isInAABB(ZoneVector min, ZoneVector max){ //Idk why i use this name for the method, i just do.
        return ((this.x <= max.x) && (this.x >=min.x) && (this.z <= max.z) && (this.z >= min.z) /* Optional code*/ && (this.y <= max.y) && (this.y >= min.y));
    }

    public boolean isInAABB(ZoneCuboid zc){ //Idk why i use this name for the method, i just do.
        ZoneVector min = zc.getMin();
        ZoneVector max = zc.getMax();
        return ((this.x <= max.x) && (this.x >=min.x) && (this.z <= max.z) && (this.z >= min.z) /* Optional code*/ && (this.y <= max.y) && (this.y >= min.y));
    }
    public Location toLocation(World world) {
        double xd = (double)this.x;
        double yd = (double)this.y;
        double zd = (double)this.z;
        return new Location(world, xd, yd, zd);
    }
}

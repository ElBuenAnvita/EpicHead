package obed.me.bedwars.objects.shop;

import obed.me.bedwars.Bedwars;
import obed.me.bedwars.config.Cfg_Shop;
import obed.me.bedwars.events.shop.Result;
import obed.me.bedwars.events.shop.UserBuyItemEvent;
import obed.me.bedwars.objects.SpawnerType;
import obed.me.bedwars.objects.game.Team;
import obed.me.bedwars.objects.game.User;
import obed.me.bedwars.utils.Colorize;
import obed.me.bedwars.utils.ComparatorUtil;
import obed.me.bedwars.utils.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import team.unnamed.gui.api.item.Button;
import team.unnamed.gui.api.item.DefaultItemClickable;
import team.unnamed.gui.api.item.ItemClickable;
import team.unnamed.gui.menu.MenuBuilder;

import java.util.*;

public class ShopInventory extends CustomInventory{
    private final HashMap<SItem, List<SItem>> shopItem = new HashMap<>();
    private final Cfg_Shop cf = Bedwars.getInstance().getCfgShop();
    private SItem quickshop = null;
    private final ItemStack barrier = ItemUtil.createItem("&cSlot disponible.", new ArrayList<>(),160,(short) 14,1);
    private final List<String> lore = new ArrayList<>(Collections.singletonList("&7↓ Items."));
    private final ItemStack panel = ItemUtil.createItem("&7↑ Categorias.", lore,160, (short) 8,1);
    private final ItemStack hpanel = ItemUtil.createItem("&a↑ Categoria Seleccionada.", lore, 160, (short) 5, 1);
    private final Button bpanel = a->{
        a.setCancelled(true);
        return true;
    };
    public HashMap<SItem, List<SItem>> getShopItem() {
        return shopItem;
    }

    @Override
    public void openInventory(Player p) {
        if(quickshop == null){
            for(SItem find : getShopItem().keySet()){
                if(!find.isQuickShopCategory())
                    continue;
                quickshop = find;
                break;
            }
        }
        User user = User.getUser(p);
        MenuBuilder menu = MenuBuilder.newBuilder(Colorize.toColor(cf.getConfig().getString("title")),
                cf.getConfig().getInt("size")/9);
        //adding panels
        long inicio = System.nanoTime();
        for (int x = 19; x <= 43; x++) {
            menu.addItem(ItemClickable.newItem(x, barrier, bpanel));
            if (((x % 10) + ((x - (x % 10)) / 10)) == 7) x += 2;
        }
        long fin = System.nanoTime();
       // double tiempo = (double) ((fin - inicio)/1000);
        System.out.println("Duración: " + (fin-inicio)/1e6 + " ms");
        //agrega los paneles debajo de las categorías.
        for (int x = 9; x <= 17; x++) {
            if(x == quickshop.getSlot()+9) menu.addItem(new DefaultItemClickable(quickshop.getSlot()+9, hpanel, bpanel));
            else menu.addItem(new DefaultItemClickable(x, panel, bpanel));
        }
        //adding categories.
        for (SItem sItem : shopItem.keySet()) {
            Button button = e -> {
                p.playSound(p.getLocation(), Sound.CLICK, Float.MAX_VALUE, Float.MAX_VALUE);
                e.setCancelled(true);
                openCategory(sItem, p);
                return true;
            };
            DefaultItemClickable item = new DefaultItemClickable(sItem.getSlot(), sItem.getIcon(), button);
            menu.addItem(item);
        }
        //adding contents.
        for (SItem content : user.getQuickShop()) {
            if(!content.getCategory().isLeveling()){
                Button buy = getBuyOption(menu,quickshop,content,p);
                DefaultItemClickable clickable = new DefaultItemClickable(content.getSlot(), content.getIcon(), buy);
                menu.addItem(clickable);
                continue;
            }
            SItem first = content.getLevelCategory().getLeveling_list().get(1);
            int lvl = getLevelingItem(p, content.getLevelCategory());
            if (lvl > 0) first = content.getLevelCategory().getLeveling_list().get((content.getLevelCategory().getLeveling_list().size() == lvl) ? (getLevelingItem(p, content.getLevelCategory())) : (getLevelingItem(p, content.getLevelCategory()) + 1));
            Button buy = getBuyOption(menu, quickshop, first, p);
            first.setSlot(content.getSlot());
            DefaultItemClickable clickable = new DefaultItemClickable(content.getSlot(), first.getIcon(), buy);
            menu.addItem(clickable);
        }
        Inventory inventory = menu.build();
        p.openInventory(inventory);
        p.playSound(p.getLocation(), Sound.NOTE_BASS, 5F,5F);
    }

    private void openCategory(SItem category, Player p){
        User user = User.getUser(p);
        MenuBuilder menu = MenuBuilder.newBuilder(Colorize.toColor(cf.getConfig().getString("title")),
                cf.getConfig().getInt("size")/9);
        for (int x = 19; x <= 43; x++) {
            menu.addItem(ItemClickable.newItem(x, barrier, bpanel));
            if (((x % 10) + ((x - (x % 10)) / 10)) == 7) x += 2;
        }
        for (int x = 9; x <= 17; x++) {
            if(x == category.getSlot()+9) menu.addItem(new DefaultItemClickable(x, hpanel, bpanel));
            else menu.addItem(new DefaultItemClickable(x, panel, bpanel));
        }
        for (SItem sItem : shopItem.keySet()) {
            Button button = e -> {
                e.setCancelled(true);
                p.playSound(p.getLocation(), Sound.CLICK, Float.MAX_VALUE, Float.MAX_VALUE);
                try{
                    openCategory(sItem, p);
                }catch (Exception exp){
                    exp.printStackTrace();
                }
                return true;
            };
            DefaultItemClickable item = new DefaultItemClickable(sItem.getSlot(), sItem.getIcon(), button);
            menu.addItem(item);
        }

        int x = 19;
        for (SItem content : ((category.isQuickShopCategory() ? user.getQuickShop() : shopItem.get(category)))) {
            try{
                if(!content.getCategory().isLeveling()){
                    Button buy = getBuyOption(menu,category,content,p);
                    DefaultItemClickable clickable = new DefaultItemClickable((content.isQuickShop() ? content.getSlot() : x), content.getIcon(), buy);
                    p.getOpenInventory().getTopInventory().setItem((content.isQuickShop() ? content.getSlot() : x), content.getIcon());
                    menu.addItem(clickable);
                } else {
                    SItem first;
                    if(category.isQuickShopCategory()){
                        int lvl = getLevelingItem(p, content.getLevelCategory());
                        first = content.getLevelCategory().getLeveling_list().get(1);
                        if(lvl > 0) first = content.getLevelCategory().getLeveling_list().get((content.getLevelCategory().getLeveling_list().size() == lvl) ? (getLevelingItem(p, content.getLevelCategory())) : (getLevelingItem(p, content.getLevelCategory())+1));
                    } else {
                        int lvl = getLevelingItem(p, content);
                        first = content.getLeveling_list().get(1);
                        if(lvl > 0) first = content.getLeveling_list().get((content.getLeveling_list().size() == lvl) ? (getLevelingItem(p, content)) : (getLevelingItem(p, content)+1));
                    }
                    Button buy = getBuyOption(menu,category,first,p);
                    first.setSlot(content.getSlot());
                    DefaultItemClickable clickable = new DefaultItemClickable((content.isQuickShop() ? content.getSlot() : x), first.getIcon(), buy);
                    p.getOpenInventory().getTopInventory().setItem((content.isQuickShop() ? content.getSlot() : x), first.getIcon());
                    menu.addItem(clickable);
                }
            }catch (Exception E){
                E.printStackTrace();
            }
            if (((x % 10) + ((x - (x % 10)) / 10)) == 7) x += 2;
            x++;
        }
        Inventory inventory = menu.build();
        p.openInventory(inventory);
    }

    private int getLevelingItem(Player p, SItem content) {
        User user = User.getUser(p);
        if(user.getBuyedItems().get(content) == null)
            return 0;
        return user.getBuyedItems().get(content).get(0).getLevel();
    }
    @Override
    public void loadInventoryData() {
        for(String key: cf.getConfig().getConfigurationSection("categories").getKeys(false)){
            ConfigurationSection sec = cf.getConfig().getConfigurationSection("categories." + key);
            ItemStack icon = ItemUtil.createItem(sec.getString("name"), sec.getStringList("lore"),
                    Integer.parseInt(sec.getString("icon").split(":")[0]),
                    (short) Integer.parseInt(sec.getString("icon").split(":")[1]),1);
            int slot = sec.getInt("slot");
            boolean priority = sec.getBoolean("priority");
            SItem index = new SItem(icon.getItemMeta().getDisplayName(), icon);
            index.setQuickShopCategory(key.equalsIgnoreCase("quick"));
            index.setSlot(slot);
            index.setAllowPriority(priority);
            index.setLeveling(sec.getBoolean("leveling"));
            shopItem.put(index, new ArrayList<>());
            if(sec.getConfigurationSection("content") == null)
                continue;
            if(!index.isLeveling()){
                for(String cKey : sec.getConfigurationSection("content").getKeys(false)){
                    //aqui va el contenido de la categoria, los SItems que contiene dentro el content del producto,
                    // si tiene el leveling activado, reformar el getter.
                    ConfigurationSection cons = sec.getConfigurationSection("content." + cKey);
                    List<String> lore = new ArrayList<>();
                    cons.getStringList("lore").forEach(val-> lore.add(val.replaceAll("%amount%", cons.getInt("cost.amount") + "").replaceAll("%type%", cons.getString("cost.type"))));
                    ItemStack sec_icon = ItemUtil.createItem(cons.getString("name"), lore,
                            Integer.parseInt(cons.getString("icon").split(":")[0]),
                            (short) Integer.parseInt(sec.getString("icon").split(":")[1]),1);
                    SItem sItem = new SItem(sec_icon.getItemMeta().getDisplayName(), sec_icon);
                    sItem.setCategory(index);
                    sItem.setKeepInventory(cons.getBoolean("onDeath"));
                    sItem.setAutoWear(cons.getBoolean("autowear"));
                    sItem.setPriority(cons.getInt("priority"));
                    sItem.setLevel((cons.getInt("level")));
                    sItem.setAmount_required(cons.getInt("cost.amount"));
                    sItem.setRequired(SpawnerType.valueOf(cons.getString("cost.type").toUpperCase(Locale.ROOT)));

                    for(String str : cons.getStringList("items")){
                        int material = Integer.parseInt(str.split(":")[0]);
                        short data = (short) Integer.parseInt(str.split(":")[1]);
                        int amount = Integer.parseInt(str.split(":")[2]);
                        ItemStack content = new ItemStack(Material.getMaterial(material),amount,data);
                        for(String ench : cons.getStringList("enchants"))
                            content.addUnsafeEnchantment(Enchantment.getById(Integer.parseInt(ench.split(":")[0])),
                                    Integer.parseInt(ench.split(":")[1]));

                        for(String rtx : cons.getStringList("NBTAG"))
                            content = ItemUtil.addNBTTag(content, rtx.split(":")[0], rtx.split(":")[1]);

                        sItem.getContent().add(content);
                    }
                    shopItem.get(index).add(sItem);
                }
                continue;
            }

            for(String cKey : sec.getConfigurationSection("content").getKeys(false)){
                ConfigurationSection cons = sec.getConfigurationSection("content." + cKey);
                List<String> lore = new ArrayList<>();
                ItemStack sec_icon = ItemUtil.createItem(cons.getString("name"), lore,
                        Integer.parseInt(cons.getString("icon").split(":")[0]),
                        (short) Integer.parseInt(sec.getString("icon").split(":")[1]),1);
                SItem sItem = new SItem(sec_icon.getItemMeta().getDisplayName(), sec_icon);
                sItem.setCategory(index);
                sItem.setKeepInventory(cons.getBoolean("onDeath"));
                sItem.setAutoWear(cons.getBoolean("autowear"));
                //load here leveling list.
                for(String str : cons.getConfigurationSection("leveling").getKeys(false)){
                    ConfigurationSection cstr = cons.getConfigurationSection("leveling." + str);
                    List<String> str_lore = new ArrayList<>();
                    cstr.getStringList("lore").forEach(val-> str_lore.add(val.replaceAll("%amount%", cstr.getInt("cost.amount") + "").replaceAll("%type%", cstr.getString("cost.type"))));
                    ItemStack str_icon = ItemUtil.createItem(cstr.getString("name"), str_lore,
                            Integer.parseInt(cstr.getString("icon").split(":")[0]),
                            (short) Integer.parseInt(cstr.getString("icon").split(":")[1]),1);
                    SItem str_item = new SItem(str_icon.getItemMeta().getDisplayName(), str_icon);
                    str_item.setCategory(index);
                    str_item.setLevelCategory(sItem);
                    str_item.setKeepInventory(sItem.isKeepInventory());
                    str_item.setAutoWear(sItem.isAutoWear());
                    str_item.setLevel(Integer.parseInt(str));
                    str_item.setAmount_required(cstr.getInt("cost.amount"));
                    str_item.setRequired(SpawnerType.valueOf(cstr.getString("cost.type").toUpperCase(Locale.ROOT)));
                    for(String str_items : cstr.getStringList("items")){
                        int material = Integer.parseInt(str_items.split(":")[0]);
                        short data = (short) Integer.parseInt(str_items.split(":")[1]);
                        int amount = Integer.parseInt(str_items.split(":")[2]);
                        ItemStack content = new ItemStack(Material.getMaterial(material),amount,data);
                        for(String ench : cstr.getStringList("enchants"))
                            content.addUnsafeEnchantment(Enchantment.getById(Integer.parseInt(ench.split(":")[0])),
                                    Integer.parseInt(ench.split(":")[1]));

                        for(String rtx : cstr.getStringList("NBTAG"))
                            content = ItemUtil.addNBTTag(content, rtx.split(":")[0], rtx.split(":")[1]);

                        str_item.getContent().add(content);
                    }
                    sItem.getLeveling_list().put(Integer.parseInt(str), str_item);
                }

                shopItem.get(index).add(sItem);
            }

        }
        getShopItem().values().forEach(list-> list.sort(new ComparatorUtil()));
    }

    @Override
    public TypeInventory getType() {
        return TypeInventory.SHOP;
    }

    private Button getBuyOption(MenuBuilder menuBuilder, SItem category, SItem content, Player p){
        return a -> {
            a.setCancelled(true);
            Player usr = (Player) a.getWhoClicked();
            User buy_user = User.getUser(usr);
            if (!a.getClick().isShiftClick()) {
                buy(p, category, content);
                return true;
            }

            if (category.isQuickShopCategory() || content.isQuickShop()) {
                //si el content es un leveling y quick-shop, el slot obtiene un valor de 0
                menuBuilder.addItem(ItemClickable.newItem(content.getSlot(), barrier, bpanel));
                p.getOpenInventory().getTopInventory().setItem(content.getSlot(), barrier);
                p.playSound(p.getLocation(),Sound.NOTE_BASS, Float.MAX_VALUE, Float.MAX_VALUE);
                buy_user.getQuickShop().remove(content);
                buy_user.getQuickShop().removeIf(find -> find.getSlot() == a.getSlot());
                return true;
            }
            p.playSound(p.getLocation(),Sound.CLICK, Float.MAX_VALUE, Float.MAX_VALUE);
            buy_user.setQuickItem(content);
            a.getWhoClicked().closeInventory();
            quickShopSetup((Player) a.getWhoClicked(), content);
            return true;
        };
    }
    private void quickShopSetup(Player p, SItem item){
        MenuBuilder menuBuilder = MenuBuilder.newBuilder("Tienda Rapida",
                cf.getConfig().getInt("size")/9);
        Button button = e->{
            e.setCancelled(true);
            return true;
        };
        menuBuilder.addItem(ItemClickable.newItem(4,item.getIcon(), button));
        ItemStack panel = ItemUtil.createItem("&cClick para establecer", new ArrayList<>(),160,(short) 14,1);
        User buy_user = User.getUser(p);
        for(int x = 19;x<=43;x++){
            Button setter = e->{
                e.setCancelled(true);
                SItem saved = item.clone();
                saved.setQuickShop(true);
                saved.setSlot(e.getSlot());
                if(item.getCategory().isLeveling())
                    buy_user.getQuickShop().removeIf(repited -> saved.getLevelCategory() == repited.getLevelCategory());
                buy_user.getQuickShop().removeIf(repited -> saved.getIcon() == repited.getIcon());
                buy_user.getQuickShop().add(saved);
                p.playSound(p.getLocation(),Sound.CLICK, Float.MAX_VALUE, Float.MAX_VALUE);
                openInventory(p);
                return true;
            };
            menuBuilder.addItem(ItemClickable.newItem(x,panel,setter));
            if(((x %10) + ((x -(x%10))/10)) == 7) x += 2;
        }
        for(SItem itm : buy_user.getQuickShop()) {
            if(itm.getCategory().isLeveling()){
                int lvl = getLevelingItem(p, itm.getLevelCategory());
                SItem first = itm.getLevelCategory().getLeveling_list().get(1);
                if(lvl > 0) first = itm.getLevelCategory().getLeveling_list().get((itm.getLevelCategory().getLeveling_list().size() == lvl) ? (getLevelingItem(p, itm.getLevelCategory())) : (getLevelingItem(p, itm.getLevelCategory())+1));
                menuBuilder.addItem(ItemClickable.newItem(itm.getSlot(), first.getIcon(), button));
                continue;
            }
            menuBuilder.addItem(ItemClickable.newItem(itm.getSlot(), itm.getIcon(), button));
        }
        p.openInventory(menuBuilder.build());
    }
    private void buy(Player p, SItem category, SItem item){
        UserBuyItemEvent userBuyItemEvent = new UserBuyItemEvent(User.getUser(p), item.getCategory(), item, Result.DISALLOW);
        userBuyItemEvent.setCancelled(true);
        User user = User.getUser(p);
        Material material = item.getRequired().getDroptype();
        int amount = item.getAmount_required();
        int count = 0;
        for(ItemStack itm : p.getInventory().getContents()){
            if(itm == null) continue;
            if(itm.getType() == Material.AIR) continue;
            if(itm.getType() == material)
                count+=itm.getAmount();
        }
        if(count < amount){
            p.playSound(p.getLocation(),Sound.NOTE_BASS, 5f,5f);
            userBuyItemEvent.setCancelled(true);
            userBuyItemEvent.setResult(Result.NOT_ENOUGH_ITEM);
            Bukkit.getPluginManager().callEvent(userBuyItemEvent);
            return;
        }

        int priority = item.getPriority();
        if(item.getCategory().isAllowPriority()){
            if(user.getBuyedItems().get(item.getCategory()) != null){
                for(SItem items : user.getBuyedItems().get(item.getCategory())){
                    if(items == item) continue;
                    if(items.getPriority() > priority){
                        userBuyItemEvent.setCancelled(true);
                        userBuyItemEvent.setResult(Result.PRIORITY_HIGH);
                        Bukkit.getPluginManager().callEvent(userBuyItemEvent);
                        return;
                    }
                }
            }
        }
        //item = first, category = content.getCategory()
        if(item.getCategory().isLeveling()){
            if(user.getBuyedItems().get(item.getLevelCategory()) != null){
                if(user.getBuyedItems().get(item.getLevelCategory()).contains(item)){
                    userBuyItemEvent.setCancelled(true);
                    userBuyItemEvent.setResult(Result.BOUGHT);
                    Bukkit.getPluginManager().callEvent(userBuyItemEvent);
                    return;
                }
                //Si no lo contiene, se limpiará la lista para que el nuevo valor se pueda obtener desde el get(0)
                user.getBuyedItems().get(item.getLevelCategory()).clear();
            }
        }
        //aquí se está agregando el content, para el leveling se debería de agregar el item.list(1).
        if(!user.getBuyedItems().containsKey((item.getCategory().isLeveling()) ? (item.getLevelCategory()) : (item.getCategory())))
            user.getBuyedItems().put((item.getCategory().isLeveling()) ? (item.getLevelCategory()) : (item.getCategory()), new ArrayList<>());

        if(!user.getBuyedItems().get((item.getCategory().isLeveling()) ? (item.getLevelCategory()) : (item.getCategory())).contains(item))
            user.getBuyedItems().get((item.getCategory().isLeveling()) ? (item.getLevelCategory()) : (item.getCategory())).add(item);

        if(item.isQuickShop() || category.isQuickShopCategory()) openInventory(p);
        else openCategory(item.getCategory(), p);
        p.getInventory().removeItem(new ItemStack(material, amount));
        userBuyItemEvent.setCancelled(false);
        userBuyItemEvent.setResult(Result.ALLOW);
        Bukkit.getPluginManager().callEvent(userBuyItemEvent);
    }
    public static void autoWear(Player p, SItem item) {
        Team team = User.getUser(p).getTeam();
        for(ItemStack i : item.getContent()){
            String str = i.getType().toString().toUpperCase(Locale.ROOT);
            if(str.contains("HELMET")) p.getInventory().setHelmet(ItemUtil.addDealerEnchantmentArmor(i, team));
            else if (str.contains("CHESTPLATE")) p.getInventory().setChestplate(ItemUtil.addDealerEnchantmentArmor(i, team));
            else if (str.contains("LEGGINGS")) p.getInventory().setLeggings(ItemUtil.addDealerEnchantmentArmor(i, team));
            else if (str.contains("BOOTS")) p.getInventory().setBoots(ItemUtil.addDealerEnchantmentArmor(i, team));
            else p.getInventory().addItem(ItemUtil.addDealerEnchantment(i, team));
        }
    }
}

package obed.me.bedwars.utils;

import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.minecraft.server.v1_8_R3.NBTTagString;
import obed.me.bedwars.objects.dealer.DItem;
import obed.me.bedwars.objects.dealer.DealerItemType;
import obed.me.bedwars.objects.game.Team;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;

public class ItemUtil {

    public static ItemStack addDealerEnchantment(ItemStack itm, Team team){
        if(team.getDealers().isEmpty()) return itm;
        for(DItem ditem : team.getDealers().values()){
            switch (ditem.getDealerItemType()){
                case DEALER_SHARPNESS:
                    if(itm.getType().toString().contains("SWORD"))
                        itm.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, (int) ditem.getEnchLevel());
                    break;
                case DEALER_MINER:
                    if(itm.getType().toString().contains("AXE") || itm.getType().toString().contains("PICKAXE"))
                        itm.addUnsafeEnchantment(Enchantment.DIG_SPEED, (int) ditem.getEnchLevel());
                    break;
                default:
                    break;
            }
        }
        return itm;
    }
    public static ItemStack addDealerEnchantmentArmor(ItemStack itm, Team team){
        if(team.getDealers().isEmpty()) return itm;
        for(DItem ditem : team.getDealers().values()){
            if(ditem.getDealerItemType() == DealerItemType.DEALER_PROTECTION){
                itm.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, (int) ditem.getEnchLevel());
                break;
            }
        }
        return itm;
    }

    public static ItemStack createItem(String name, List<String> lore, Material material, int amount) {
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();
        assert meta != null;
        if (name != null)
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));

        if(lore != null){
            List<String> colored = new ArrayList<>();
            for(String str : lore)
                colored.add(ChatColor.translateAlternateColorCodes('&', str));
            meta.setLore(colored);
        }

        item.setItemMeta(meta);
        return item;
    }
    public static ItemStack createItem(String name, List<String> lore, int material_id, short data, int amount){
        ItemStack item = new ItemStack(Material.getMaterial(material_id),amount, data);
        ItemMeta meta = item.getItemMeta();
        assert meta != null;
        if (name != null)
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        if(lore != null){
            List<String> colored = new ArrayList<>();
            for(String str : lore)
                colored.add(ChatColor.translateAlternateColorCodes('&', str));
            meta.setLore(colored);
        }

        item.setItemMeta(meta);
        return item;
    }
    public static ItemStack setLore(ItemStack item, List<String> lore){
        ItemMeta meta = item.getItemMeta();
        if(lore != null){
            List<String> colored = new ArrayList<>();
            for(String str : lore)
                colored.add(ChatColor.translateAlternateColorCodes('&', str));
            meta.setLore(colored);
        }

        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack addNBTTag(ItemStack item, String tag, String data){
        net.minecraft.server.v1_8_R3.ItemStack nmsItem = CraftItemStack.asNMSCopy(item);
        NBTTagCompound compound = (nmsItem.hasTag()) ? nmsItem.getTag() : new NBTTagCompound();
        compound.set(tag, new NBTTagString(data));
        nmsItem.setTag(compound);
        return CraftItemStack.asBukkitCopy(nmsItem);
    }

    public static String getNBTTag(ItemStack item, String tag){
        net.minecraft.server.v1_8_R3.ItemStack nmsItem = CraftItemStack.asNMSCopy(item);
        NBTTagCompound compound = (nmsItem.hasTag()) ? nmsItem.getTag() : new NBTTagCompound();
        return compound.getString(tag);
    }

    public static ItemStack removeNBTag(ItemStack item){
        net.minecraft.server.v1_8_R3.ItemStack nmsItem = CraftItemStack.asNMSCopy(item);
        NBTTagCompound compound = new NBTTagCompound();
        nmsItem.setTag(compound);
        return CraftItemStack.asBukkitCopy(nmsItem);
    }
}

package obed.me.bedwars.objects.game;

import obed.me.bedwars.objects.Spawner;
import obed.me.bedwars.objects.Status;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Map extends BukkitRunnable {
    private String name;
    private World world;
    private int minPlayers;
    private boolean started;
    private final List<User> Players = new ArrayList<>();
    private final HashMap<String, Team> teamsList = new HashMap<>();
    private final List<Spawner> spawnersList = new ArrayList<>();
    private int LobbyTime;
    private int GameTime;
    private int playersPerTeam;
    private Status status;
    private Location spectatorLocation;
    private Location LobbyLocation;
    private int maxHeight;
    private Location lobbycord1;
    private Location lobbycord2;


    @Override
    public void run() {
        /*
         * TODO:
         * - muchas cosas.
         */
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public World getWorld() {
        return world;
    }

    public void setWorld(World world) {
        this.world = world;
    }

    public int getMaxPlayers() {
        return teamsList.size() * playersPerTeam;
    }
    public int getPlayersPerTeam(){ return playersPerTeam;}
    public int getMinPlayers() {
        return minPlayers;
    }

    public void setMinPlayers(int minPlayers) {
        this.minPlayers = minPlayers;
    }

    public boolean isStarted() {
        return started;
    }

    public void setStarted(boolean started) {
        this.started = started;
    }

    public List<User> getPlayers() {
        return Players;
    }

    public HashMap<String, Team> getTeamsList() {
        return teamsList;
    }

    public List<Spawner> getSpawnersList() {
        return spawnersList;
    }

    public int getLobbyTime() {
        return LobbyTime;
    }

    public void setLobbyTime(int lobbyTime) {
        LobbyTime = lobbyTime;
    }

    public int getGameTime() {
        return GameTime;
    }

    public void setGameTime(int gameTime) {
        GameTime = gameTime;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Location getLobbyLocation() {
        return LobbyLocation;
    }

    public void setLobbyLocation(Location lobbyLocation) {
        LobbyLocation = lobbyLocation;
    }

    public Location getSpectatorLocation() {
        return spectatorLocation;
    }

    public void setSpectatorLocation(Location spectatorLocation) {
        this.spectatorLocation = spectatorLocation;
    }

    public Location getLobbycord1() {
        return lobbycord1;
    }

    public void setLobbycord1(Location lobbycord1) {
        this.lobbycord1 = lobbycord1;
    }

    public Location getLobbycord2() {
        return lobbycord2;
    }

    public void setLobbycord2(Location lobbycord2) {
        this.lobbycord2 = lobbycord2;
    }

    public int getMaxHeight() {
        return maxHeight;
    }

    public void setMaxHeight(int maxHeight) {
        this.maxHeight = maxHeight;
    }

    public void setPlayersPerTeam(int playersPerTeam) {
        this.playersPerTeam = playersPerTeam;
    }

    public Team[] getTeamRemining() {
        return null;
    }

    public Team getPlayerTeam(Player p){
        for(Team team : getTeamRemining()){
            if(!team.getNamedPlayers().contains(p.getName())) continue;
            if(!team.isBedDestroy()) return team;
        }
        return null;

    }
}

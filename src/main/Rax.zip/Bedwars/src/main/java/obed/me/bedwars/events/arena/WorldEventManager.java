package obed.me.bedwars.events.arena;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.weather.WeatherChangeEvent;

public class WorldEventManager implements Listener {
    @EventHandler
    public void Weather(WeatherChangeEvent e){
        e.setCancelled(true);
    }

}

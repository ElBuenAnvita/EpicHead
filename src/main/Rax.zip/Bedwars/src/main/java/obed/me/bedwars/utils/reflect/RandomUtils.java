package obed.me.bedwars.utils.reflect;

import java.util.Random;

public final class RandomUtils {
    private RandomUtils() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static final Random RANDOM = new Random();

    public static int randomInt(int min, int max) {
        return RANDOM.nextInt(max - min + 1) + min;
    }

    public static boolean randomBool() {
        return RANDOM.nextBoolean();
    }

    public static float randomFloat() {
        return RANDOM.nextFloat();
    }
}

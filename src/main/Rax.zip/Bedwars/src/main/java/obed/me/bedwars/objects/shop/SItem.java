package obed.me.bedwars.objects.shop;

import lombok.Getter;
import lombok.Setter;
import obed.me.bedwars.objects.SpawnerType;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Getter
@Setter
public class SItem implements Cloneable {
    private String name;
    private List<String> lore;
    private ItemStack icon;
    private List<ItemStack> content = new ArrayList<>();
    private boolean keepInventory;
    private boolean autoWear;
    private boolean allowPriority;
    private SItem category;
    private SItem levelCategory;
    private int level;
    private boolean leveling;
    private boolean quickShop;
    private boolean quickShopCategory;
    private HashMap<Integer, SItem> leveling_list = new HashMap<>();
    private SpawnerType required;
    private int amount_required;
    private int priority;
    private int slot;
    public static HashMap<String, SItem> itemHashMap = new HashMap<>();

    public SItem(String name, ItemStack icon){
        this.name = name;
        this.icon = icon;
    }

    @Override
    public SItem clone() {
        try {
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return (SItem) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}

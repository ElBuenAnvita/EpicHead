package obed.me.bedwars.events.shop;

public enum Result {
    NOT_ENOUGH_ITEM,
    PRIORITY_HIGH,
    LEVEL_HIGH,
    ALLOW,
    DISALLOW,
    BOUGHT
}

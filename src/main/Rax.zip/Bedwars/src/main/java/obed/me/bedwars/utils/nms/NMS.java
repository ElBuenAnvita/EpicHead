package obed.me.bedwars.utils.nms;

import com.google.common.collect.Maps;

import io.netty.channel.Channel;
import io.netty.channel.ChannelPipeline;
import java.lang.reflect.Field;
import java.util.Map;

import obed.me.bedwars.utils.nms.version.NMS_1_8;
import obed.me.bedwars.utils.reflect.*;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
public abstract class NMS {
    protected static final Map<String, Pair<Integer, Float>> mapEntityTypes = Maps.newHashMap();

    protected static final Class<?> PACKET_CLASS;

    protected static final ReflectMethod CRAFT_PLAYER_GET_HANDLE_METHOD;

    protected static final ReflectMethod PLAYER_CONNECTION_SEND_PACKET_METHOD;

    protected static ReflectField<?> ENTITY_PLAYER_CONNECTION_FIELD;

    protected static ReflectField<?> PLAYER_CONNECTION_NETWORK_MANAGER_FIELD;

    protected static ReflectField<?> NETWORK_MANAGER_CHANNEL_FIELD;

    private static NMS instance;

    static {
        Class<?> playerConnectionClass, craftPlayerClass;
        if (Common.SERVER_VERSION.isAfterOrEqual(Version.v1_17_R1)) {
            Class<?> entityPlayerClass = ReflectionUtil.getNMClass("server.level.EntityPlayer");
            playerConnectionClass = ReflectionUtil.getNMClass("server.network.PlayerConnection");
            craftPlayerClass = ReflectionUtil.getObcClass("entity.CraftPlayer");
            Class<?> networkManagerClass = ReflectionUtil.getNMClass("network.NetworkManager");
            PACKET_CLASS = ReflectionUtil.getNMClass("network.protocol.Packet");
            for (Field field : entityPlayerClass.getFields()) {
                if (field.getType().isAssignableFrom(playerConnectionClass) && ENTITY_PLAYER_CONNECTION_FIELD == null) {
                    ENTITY_PLAYER_CONNECTION_FIELD = new ReflectField(entityPlayerClass, field.getName());
                    break;
                }
            }
            for (Field field : networkManagerClass.getFields()) {
                if (field.getType().isAssignableFrom(Channel.class) && NETWORK_MANAGER_CHANNEL_FIELD == null) {
                    NETWORK_MANAGER_CHANNEL_FIELD = new ReflectField(networkManagerClass, field.getName());
                    break;
                }
            }
            for (Field field : playerConnectionClass.getFields()) {
                if (field.getType().isAssignableFrom(networkManagerClass) && PLAYER_CONNECTION_NETWORK_MANAGER_FIELD == null) {
                    PLAYER_CONNECTION_NETWORK_MANAGER_FIELD = new ReflectField(playerConnectionClass, field.getName());
                    break;
                }
            }
        } else {
            Class<?> entityPlayerClass = ReflectionUtil.getNMSClass("EntityPlayer");
            playerConnectionClass = ReflectionUtil.getNMSClass("PlayerConnection");
            craftPlayerClass = ReflectionUtil.getObcClass("entity.CraftPlayer");
            Class<?> networkManagerClass = ReflectionUtil.getNMSClass("NetworkManager");
            PACKET_CLASS = ReflectionUtil.getNMSClass("Packet");
            ENTITY_PLAYER_CONNECTION_FIELD = new ReflectField(entityPlayerClass, "playerConnection");
            PLAYER_CONNECTION_NETWORK_MANAGER_FIELD = new ReflectField(playerConnectionClass, "networkManager");
            NETWORK_MANAGER_CHANNEL_FIELD = new ReflectField(networkManagerClass, "channel");
        }
        CRAFT_PLAYER_GET_HANDLE_METHOD = new ReflectMethod(craftPlayerClass, "getHandle", new Class[0]);
        if (Common.SERVER_VERSION.isAfterOrEqual(Version.v1_18_R1)) {
            PLAYER_CONNECTION_SEND_PACKET_METHOD = new ReflectMethod(playerConnectionClass, "a", new Class[] { PACKET_CLASS });
        } else {
            PLAYER_CONNECTION_SEND_PACKET_METHOD = new ReflectMethod(playerConnectionClass, "sendPacket", new Class[] { PACKET_CLASS });
        }
        mapEntityTypes.put("BAT", new Pair(Integer.valueOf(3), Float.valueOf(0.9F)));
        mapEntityTypes.put("BLAZE", new Pair(Integer.valueOf(4), Float.valueOf(1.8F)));
        mapEntityTypes.put("CAVE_SPIDER", new Pair(Integer.valueOf(6), Float.valueOf(0.5F)));
        mapEntityTypes.put("CHICKEN", new Pair(Integer.valueOf(7), Float.valueOf(0.7F)));
        mapEntityTypes.put("COD", new Pair(Integer.valueOf(8), Float.valueOf(0.3F)));
        mapEntityTypes.put("COW", new Pair(Integer.valueOf(9), Float.valueOf(1.4F)));
        mapEntityTypes.put("CREEPER", new Pair(Integer.valueOf(10), Float.valueOf(1.7F)));
        mapEntityTypes.put("DONKEY", new Pair(Integer.valueOf(11), Float.valueOf(1.39648F)));
        mapEntityTypes.put("DOLPHIN", new Pair(Integer.valueOf(12), Float.valueOf(0.6F)));
        mapEntityTypes.put("DROWNED", new Pair(Integer.valueOf(14), Float.valueOf(1.95F)));
        mapEntityTypes.put("ELDER_GUARDIAN", new Pair(Integer.valueOf(15), Float.valueOf(2.9F)));
        mapEntityTypes.put("ENDER_DRAGON", new Pair(Integer.valueOf(17), Float.valueOf(8.0F)));
        mapEntityTypes.put("ENDERMAN", new Pair(Integer.valueOf(18), Float.valueOf(2.9F)));
        mapEntityTypes.put("ENDERMITE", new Pair(Integer.valueOf(19), Float.valueOf(0.3F)));
        mapEntityTypes.put("EVOKER", new Pair(Integer.valueOf(21), Float.valueOf(1.95F)));
        mapEntityTypes.put("HORSE", new Pair(Integer.valueOf(28), Float.valueOf(1.6F)));
        mapEntityTypes.put("HUSK", new Pair(Integer.valueOf(30), Float.valueOf(1.95F)));
        mapEntityTypes.put("ILLUSIONER", new Pair(Integer.valueOf(31), Float.valueOf(1.95F)));
        mapEntityTypes.put("LLAMA", new Pair(Integer.valueOf(36), Float.valueOf(1.87F)));
        mapEntityTypes.put("MAGMA_CUBE", new Pair(Integer.valueOf(38), Float.valueOf(0.51000005F)));
        mapEntityTypes.put("MULE", new Pair(Integer.valueOf(46), Float.valueOf(1.6F)));
        mapEntityTypes.put("MUSHROOM_COW", new Pair(Integer.valueOf(47), Float.valueOf(1.4F)));
        mapEntityTypes.put("OCELOT", new Pair(Integer.valueOf(48), Float.valueOf(0.7F)));
        mapEntityTypes.put("PARROT", new Pair(Integer.valueOf(50), Float.valueOf(0.9F)));
        mapEntityTypes.put("PIG", new Pair(Integer.valueOf(51), Float.valueOf(0.9F)));
        mapEntityTypes.put("PUFFERFISH", new Pair(Integer.valueOf(52), Float.valueOf(0.7F)));
        mapEntityTypes.put("PIG_ZOMBIE", new Pair(Integer.valueOf(53), Float.valueOf(1.8F)));
        mapEntityTypes.put("POLAR_BEAR", new Pair(Integer.valueOf(54), Float.valueOf(1.4F)));
        mapEntityTypes.put("RABBIT", new Pair(Integer.valueOf(56), Float.valueOf(0.5F)));
        mapEntityTypes.put("SALMON", new Pair(Integer.valueOf(57), Float.valueOf(0.4F)));
        mapEntityTypes.put("SHEEP", new Pair(Integer.valueOf(58), Float.valueOf(1.3F)));
        mapEntityTypes.put("SILVERFISH", new Pair(Integer.valueOf(61), Float.valueOf(0.3F)));
        mapEntityTypes.put("SKELETON", new Pair(Integer.valueOf(62), Float.valueOf(1.99F)));
        mapEntityTypes.put("SKELETON_HORSE", new Pair(Integer.valueOf(63), Float.valueOf(1.6F)));
        mapEntityTypes.put("SLIME", new Pair(Integer.valueOf(64), Float.valueOf(0.51000005F)));
        mapEntityTypes.put("SNOWMAN", new Pair(Integer.valueOf(66), Float.valueOf(1.9F)));
        mapEntityTypes.put("GUARDIAN", new Pair(Integer.valueOf(68), Float.valueOf(0.85F)));
        mapEntityTypes.put("SPIDER", new Pair(Integer.valueOf(69), Float.valueOf(0.9F)));
        mapEntityTypes.put("SQUID", new Pair(Integer.valueOf(70), Float.valueOf(1.8F)));
        mapEntityTypes.put("STRAY", new Pair(Integer.valueOf(71), Float.valueOf(1.99F)));
        mapEntityTypes.put("TROPICAL_FISH", new Pair(Integer.valueOf(72), Float.valueOf(0.4F)));
        mapEntityTypes.put("TURTLE", new Pair(Integer.valueOf(73), Float.valueOf(0.4F)));
        mapEntityTypes.put("VEX", new Pair(Integer.valueOf(78), Float.valueOf(0.95F)));
        mapEntityTypes.put("VILLAGER", new Pair(Integer.valueOf(79), Float.valueOf(1.95F)));
        mapEntityTypes.put("IRON_GOLEM", new Pair(Integer.valueOf(80), Float.valueOf(2.7F)));
        mapEntityTypes.put("VINDICATOR", new Pair(Integer.valueOf(81), Float.valueOf(1.95F)));
        mapEntityTypes.put("WITCH", new Pair(Integer.valueOf(82), Float.valueOf(1.95F)));
        mapEntityTypes.put("WITHER", new Pair(Integer.valueOf(83), Float.valueOf(3.5F)));
        mapEntityTypes.put("WITHER_SKELETON", new Pair(Integer.valueOf(84), Float.valueOf(2.4F)));
        mapEntityTypes.put("WOLF", new Pair(Integer.valueOf(86), Float.valueOf(0.85F)));
        mapEntityTypes.put("ZOMBIE", new Pair(Integer.valueOf(87), Float.valueOf(1.95F)));
        mapEntityTypes.put("ZOMBIE_HORSE", new Pair(Integer.valueOf(88), Float.valueOf(1.6F)));
        mapEntityTypes.put("ZOMBIE_VILLAGER", new Pair(Integer.valueOf(89), Float.valueOf(1.95F)));
        mapEntityTypes.put("PHANTOM", new Pair(Integer.valueOf(90), Float.valueOf(0.5F)));
        mapEntityTypes.put("ENDER_CRYSTAL", new Pair(Integer.valueOf(51), Float.valueOf(2.0F)));
        mapEntityTypes.put("ARROW", new Pair(Integer.valueOf(60), Float.valueOf(0.5F)));
        mapEntityTypes.put("SNOWBALL", new Pair(Integer.valueOf(61), Float.valueOf(0.25F)));
        mapEntityTypes.put("EGG", new Pair(Integer.valueOf(62), Float.valueOf(0.25F)));
        mapEntityTypes.put("FIREBALL", new Pair(Integer.valueOf(63), Float.valueOf(1.0F)));
        mapEntityTypes.put("SMALL_FIREBALL", new Pair(Integer.valueOf(64), Float.valueOf(0.3125F)));
        mapEntityTypes.put("ENDER_PEARL", new Pair(Integer.valueOf(65), Float.valueOf(0.25F)));
        mapEntityTypes.put("ENDER_SIGNAL", new Pair(Integer.valueOf(72), Float.valueOf(0.25F)));
        mapEntityTypes.put("FIREWORK", new Pair(Integer.valueOf(76), Float.valueOf(0.25F)));
    }

    public static NMS getInstance() {
        return instance;
    }

    public static void init() {
        instance = new NMS_1_8();
//        if (Common.SERVER_VERSION.isBefore(Version.v1_9_R1)) {
//            instance = (NMS)new NMS_1_8();
//        } else if (Common.SERVER_VERSION.isBefore(Version.v1_17_R1)) {
//            instance = (NMS)new NMS_1_9();
//        } else {
//            instance = (NMS)new NMS_1_17();
//        }
    }

    protected Object getPlayerConnection(Player player) {
        Object entityPlayer = CRAFT_PLAYER_GET_HANDLE_METHOD.invoke(player, new Object[0]);
        return ENTITY_PLAYER_CONNECTION_FIELD.getValue(entityPlayer);
    }

    public void sendPacket(Player player, Object packet) {
        if (packet == null || !PACKET_CLASS.isAssignableFrom(packet.getClass()))
            return;
        Object playerConnection = getPlayerConnection(player);
        PLAYER_CONNECTION_SEND_PACKET_METHOD.invoke(playerConnection, new Object[] { packet });
    }

    public ChannelPipeline getPipeline(Player player) {
        Object playerConnection = getPlayerConnection(player);
        Object networkManager = PLAYER_CONNECTION_NETWORK_MANAGER_FIELD.getValue(playerConnection);
        Channel channel = (Channel)NETWORK_MANAGER_CHANNEL_FIELD.getValue(networkManager);
        return channel.pipeline();
    }

    public int getEntityTypeId(EntityType type) {
        if (type == null)
            return -1;
        String name = type.name();
        if (mapEntityTypes.containsKey(name))
            return ((Integer)((Pair)mapEntityTypes.get(name)).getKey()).intValue();
        return -1;
    }

    public float getEntityHeigth(EntityType type) {
        if (type == null)
            return 0.0F;
        String name = type.name();
        if (mapEntityTypes.containsKey(name))
            return ((Float)((Pair)mapEntityTypes.get(name)).getValue()).floatValue();
        return 0.0F;
    }

    public abstract int getFreeEntityId();

    public abstract void showFakeEntity(Player paramPlayer, Location paramLocation, EntityType paramEntityType, int paramInt);

    public abstract void showFakeEntityLiving(Player paramPlayer, Location paramLocation, EntityType paramEntityType, int paramInt);

    public abstract void showFakeEntityArmorStand(Player paramPlayer, Location paramLocation, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);

    public abstract void showFakeEntityItem(Player paramPlayer, Location paramLocation, ItemStack paramItemStack, int paramInt);

    public abstract void updateFakeEntityCustomName(Player paramPlayer, String paramString, int paramInt);

    public abstract void teleportFakeEntity(Player paramPlayer, Location paramLocation, int paramInt);

    public abstract void helmetFakeEntity(Player paramPlayer, ItemStack paramItemStack, int paramInt);

    public abstract void attachFakeEnity(Player paramPlayer, int paramInt1, int paramInt2);

    public abstract void hideFakeEntities(Player paramPlayer, int... paramVarArgs);

    public abstract void showFakeEntityGiant(Player paramPlayer, Location paramLocation, int paramInt, boolean paramBoolean1, boolean paramBoolean2, ItemStack paramItemStack);
}
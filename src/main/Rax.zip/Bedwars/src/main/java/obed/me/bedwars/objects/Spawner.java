package obed.me.bedwars.objects;

import obed.me.bedwars.Bedwars;
import obed.me.bedwars.utils.ItemUtil;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Arrays;

public class Spawner extends BukkitRunnable {

    private String name;
    private Hologram hologram;
    private SpawnerType type;
    private int level = 1;
    private Location location;
    private ArmorStand entity;
    private int max_stack = Bedwars.getInstance().getArenaConfig().getConfig().getInt("default.spawners.max-stack");
    private int level_time = Bedwars.getInstance().getArenaConfig().getConfig().getInt("default.time.level_up");
    private int drop_time = 30;
   private final float rotation = Float.parseFloat(Bedwars.getInstance().getArenaConfig().getConfig().getString("default.spawners.animation.rotation"));
   private final String title = Bedwars.getInstance().getArenaConfig().getConfig().getString("default.spawners.name");
    public Spawner(String name, SpawnerType type, Location loc) {
        this.name = name;
        this.type = type;
        this.location = loc.add(0,1,0);
        if(type.getName().equalsIgnoreCase("TEAM")){
            this.location.subtract(0,0.5,0);
            return;
        }
        this.entity = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
        this.entity.setVisible(false);
        this.entity.setBasePlate(false);
        this.entity.setArms(false);
        this.entity.setMarker(false);
        this.entity.setCanPickupItems(false);
        this.entity.setGravity(false);
        this.entity.setRemoveWhenFarAway(false);
        this.entity.setHelmet(new ItemStack(type.getBlockType()));
        this.entity.setCustomNameVisible(false);
        this.hologram = new Hologram(loc, Arrays.asList(title.split("\n")), 0.2f);
    }

    public void destroy(){
        cancel();
        if(this.entity != null)
            this.entity.remove();
        if(this.hologram != null)
            this.hologram.destroy();
    }
    public void run2(){
       if(!this.type.getName().equalsIgnoreCase("TEAM")){
           Location new_Angle = this.entity.getLocation();
           new_Angle.setYaw(new_Angle.getYaw()+rotation);
           this.entity.teleport(new_Angle);
       }
    }


    int count = drop_time;
    int lvl_count = 0;
    @Override
    public void run() {
        count--; lvl_count++;
        if(!type.getName().equalsIgnoreCase("TEAM")){
            String c_title = ChatColor.translateAlternateColorCodes('&', title)
                    .replaceAll("%type%", type.getName())
                    .replaceAll("%level%", LevelI())
                    .replaceAll("%time%", count + "");
            this.hologram.update(Arrays.asList(c_title.split("\n")));

            if(getLevel() >= 4)
                return;

            if(lvl_count >= level_time){
                setLevel(getLevel()+1);
                setDrop_time((int)(drop_time/1.5));
                lvl_count =0;
            }
        }
        if(count <= 0){
            dropItem();
            count = drop_time;
        }



    }

    public void dropItem(){
        new BukkitRunnable(){
            Location origin;
            @Override
            public void run() {
                origin = location.clone();
                int max = 0;

                for(Entity ent : origin.getWorld().getNearbyEntities(origin.subtract(0,1,0),4,4,4)){
                    if(ent instanceof Item){
                       Item item = (Item) ent;
                       item.setVelocity(new Vector(0,0,0));
                       ItemStack itemStack = item.getItemStack();
                        if(itemStack.getType() == type.getDroptype()){
                            max = max + itemStack.getAmount();
                        }

                    }
                }
                if(max >= getMax_stack())
                    return;

                ItemStack item = ItemUtil.addNBTTag(new ItemStack(type.getDroptype()), "spawner-drop", type.getName());
                Item itm = origin.getWorld().dropItem(origin.add(0,1,0), item);
                itm.setVelocity(new Vector(0,0,0));
            }
        }.runTask(Bedwars.getInstance());

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SpawnerType getType() {
        return type;
    }

    public void setType(SpawnerType type) {
        this.type = type;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public ArmorStand getEntity() {
        return entity;
    }

    public void setEntity(ArmorStand entity) {
        this.entity = entity;
    }

    public int getLevel() {
        return level;
    }
    public String LevelI(){
        switch (level){
            case 1:
                return "I";
            case 2:
                return "II";
            case 3:
                return "III";
            case 4:
                return "IV";
            default:
                throw new IllegalStateException("Unexpected value: " + level);
        }
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getLevel_time() {
        return level_time;
    }

    public void setLevel_time(int level_time) {
        this.level_time = level_time;
    }

    public int getDrop_time() {
        return drop_time;
    }

    public void setDrop_time(int drop_time) {
        this.drop_time = drop_time;
    }
    public Hologram getHologram(){
        return this.hologram;
    }

    public int getMax_stack() {
        return max_stack;
    }

    public void setMax_stack(int max_stack) {
        this.max_stack = max_stack;
    }
}

package obed.me.bedwars.utils;

import org.bukkit.plugin.Plugin;

public interface PacketListener {
    public void startListening(Plugin plugin);
}

package obed.me.bedwars.objects.dealer;

import lombok.Getter;
import lombok.Setter;
import obed.me.bedwars.objects.game.Team;
import org.bukkit.Location;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class Dealer {
    private Team team;
    private Location location;
    private List<DItem> traps = new ArrayList<>();
    private List<DItem> dealers = new ArrayList<>();

    public DItem containsDealer(DItem itm){
        for(DItem dItem : dealers){
            if(dItem.getIdentifier().equalsIgnoreCase(itm.getIdentifier()))
                return dItem;
        }
        return null;
    }
}

package obed.me.bedwars.objects;

public enum ScoreType {
    LOBBY_SCORE("lobby_score"),
    ARENA_SCORE("arena_score"),
    WAITING_SCORE("waiting_score");
    private final String text;
    ScoreType(String str) {
        this.text = str;
    }

    public String toString() {
        return text;
    }
}

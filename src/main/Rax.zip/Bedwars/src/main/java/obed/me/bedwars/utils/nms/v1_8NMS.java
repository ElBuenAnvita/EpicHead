package obed.me.bedwars.utils.nms;

import obed.me.bedwars.Bedwars;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.lang.reflect.Constructor;

public class v1_8NMS implements INMS{

    @Override
    public void HideArmor(Player p, int value, ItemStack item) {
        try{
            Class<?> craft =  getNMSClass("ItemStack");
           Constructor<?> packetconstructor = getNMSClass("PacketPlayOutEntityEquipment").getConstructor(int.class, int.class,craft);

           Object packet  = packetconstructor.newInstance(p.getEntityId(), value, getCraftItem(item));
            for(Player pall : Bukkit.getOnlinePlayers()){
               if(pall != p)
                   sendPacket(pall, packet);
            }

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void sendPacket(Player p, Object packet) {
        try{
            Object handle = p.getClass().getMethod("getHandle").invoke(p);
            Object playerconection = handle.getClass().getField("playerConnection").get(handle);
            playerconection.getClass().getMethod("sendPacket", getNMSClass("Packet")).invoke(playerconection, packet);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public Class<?> getNMSClass(String name) {
        String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
        try{
            return Class.forName("net.minecraft.server." + version + "." + name);
        } catch (ClassNotFoundException e){
            e.printStackTrace();
            return null;
        }
    }
    @Override
    public Object getCraftItem(ItemStack itemStack) {
        Class<?> bukkitClass = getBukkitClass("inventory.CraftItemStack");
        try {
            // return a craftItemStack
            return bukkitClass.getMethod("asNMSCopy", ItemStack.class).invoke(bukkitClass, itemStack);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    @Override
    public Class<?> getBukkitClass(String name) {
        String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
        try {
            return Class.forName("org.bukkit.craftbukkit." + version + "." + name);
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}

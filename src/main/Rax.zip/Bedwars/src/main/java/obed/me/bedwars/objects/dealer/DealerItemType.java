package obed.me.bedwars.objects.dealer;

public enum DealerItemType {
    DEALER_HEALER,
    DEALER_DRAGON,
    DEALER_ALARM,
    DEALER_GENERATOR,
    DEALER_PROTECTION,
    DEALER_MINER,
    DEALER_SHARPNESS,
    TRAP_BLINDNESS,
    TRAP_ANTIMINER,
    TRAP_HEALER
}

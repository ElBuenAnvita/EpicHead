package obed.me.bedwars.objects;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.server.v1_8_R3.*;
import obed.me.bedwars.Bedwars;
import obed.me.bedwars.managers.NPCManager;
import obed.me.bedwars.objects.shop.TypeInventory;
import obed.me.bedwars.utils.JsonUtil;
import obed.me.bedwars.utils.reflect.Reflection;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.util.CraftChatMessage;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.json.JSONArray;

import java.lang.reflect.Field;
import java.util.*;

@Getter
@Setter
public class NPC extends Reflection {

    private int entityID;
    private String name;
    private Location location;
    private GameProfile gameprofile;
    private Hologram displayname;
    private TypeInventory typeInventory;
    private boolean spawned;
    public NPC(String name, Location location){
        this.name = name;
        this.entityID = (int)Math.ceil(Math.random() * 1000) + 2000;
        this.location = location;
        this.gameprofile = new GameProfile(UUID.randomUUID(), name);
        this.gameprofile.getProperties().put("textures", new Property("textures", "eyJ0aW1lc3RhbXAiOjE1MTUzMzczNTExMjk" +
                "sInByb2ZpbGVJZCI6Ijg2NjdiYTcxYjg1YTQwMDRhZjU0NDU3YTk3MzRlZWQ3IiwicHJvZmlsZU5hbWUiOiJTdGV2ZSIsInNpZ2" +
                "5hdHVyZVJlcXVpcmVkIjp0cnVlLCJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQub" +
                "mV0L3RleHR1cmUvNDU2ZWVjMWMyMTY5YzhjNjBhN2FlNDM2YWJjZDJkYzU0MTdkNTZmOGFkZWY4NGYxMTM0M2RjMTE4OGZlMTM4" +
                "In0sIkNBUEUiOnsidXJsIjoiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9iNzY3ZDQ4MzI1ZWE1MzI0NTY" +
                "xNDA2YjhjODJhYmJkNGUyNzU1ZjExMTUzY2Q4NWFiMDU0NWNjMiJ9fX0", "oQHxJ9U7oi/JOeC5C9wtLcoqQ/Uj5j8mfSL" +
                "aPo/zMQ1GP/IjB+pFmfy5JOOaX94Ia98QmLLd+AYacnja60DhO9ljrTtL/tM7TbXdWMWW7A2hJkEKNH/wnBkSIm0EH8WhH+m9+8" +
                "2pkTB3h+iDGHyc+Qb9tFXWLiE8wvdSrgDHPHuQAOgGw6BfuhdSZmv2PGWXUG02Uvk6iQ7ncOIMRWFlWCsprpOw32yzWLSD8UeUU" +
                "io6SlUyuBIO+nJKmTRWHnHJgTLqgmEqBRg0B3GdML0BncMlMHq/qe9x6gTlDCJATLTFJg4kDEF+kUa4+P0BDdPFrgApFUeK4Bz1" +
                "w7Qxls4zKQQJNJw58nhvKk/2yQnFOOUqfRx/DeIDLCGSTEJr4VjKIVThnvkocUDsH8DLk4/Xt9qKWh3ZxXtxoKPDvFP5iyxIOfZ" +
                "dkZu/H0qlgRTqF8RP8AnXf2lgnarfty8G7q7/4KQwWC1CIn9MmaMwv3MdFDlwdAjHhvpyBYYTnL11YDBSUg3b6+QmrWWm1DXcHr" +
                "wkcS0HI82VHYdg8uixzN57B3DGRSlh2qBWHJTb0zF8uryveCZppHl/ULa/2vAt6XRXURniWU4cTQKQAGqjByhWSbUM0XHFgcuKj" +
                "GFVlJ4HEzBiXgY3PtRF6NzfsUZ2gQI9o12x332USZiluYrf+OLhCa8="));
        NPCManager.npcList.put(this.entityID, this);
    }
    public void onClick(Player p){
        switch (typeInventory){
            case SHOP:
                Bedwars.getInstance().getShopInventory().openInventory(p);
                break;
            default:
                break;
        }
    }

    public void follow(){
        if(!this.spawned)
            return;

        PacketPlayOutEntityHeadRotation  rotation = new PacketPlayOutEntityHeadRotation ();
        setValue(rotation, "a", entityID);
        Bukkit.getScheduler().runTaskAsynchronously(Bedwars.getInstance(), new Runnable() {
            Player selected = null;
            @Override
            public void run() {
                if(selected == null){
                    for(Entity ent : getLocation().getWorld().getNearbyEntities(getLocation(), 3,3,3)){
                        if(ent instanceof Player) {
                            selected = (Player) ent;
                            break;
                        }
                    }
                }
                if(selected == null)
                    return;
                if(selected.getLocation().distance(getLocation()) >=3) {
                    selected = null;
                    return;
                }

                Vector vector = selected.getLocation().toVector().subtract(getLocation().toVector());
                location.setDirection(vector);
                setValue(rotation, "b", (byte) ((int) (location.getYaw()* 256.0F / 360.0F)));
                sendPacket(new PacketPlayOutEntity.PacketPlayOutEntityLook(entityID,  (byte) ((location.getYaw() * 256.0F) / 360.0F), (byte) 0,true));
                sendPacket(rotation, selected);
            }
        });
    }

    public void setDisplayName(String args){
        this.displayname = new Hologram(location, Arrays.asList(args.split("\n")),0.3);
    }
    public void setSkin(String name){
        String uuid = JsonUtil.getPlayerUUID(name);
        if(uuid == null) return;
        JSONArray array = JsonUtil.getProfileData(uuid);
        if(array == null) return;
        GameProfile profile = new GameProfile(UUID.randomUUID(), this.name);
        profile.getProperties().put("textures", new Property("textures",
                JsonUtil.getKey(array, "value"), JsonUtil.getKey(array, "signature")));
        this.gameprofile = profile;
    }

    public void despawn(Player p){
        this.spawned = false;
        PacketPlayOutEntityDestroy packet = new PacketPlayOutEntityDestroy(entityID);
        rmvFromTablist();
        sendPacket(packet, p);
    }
    public void destroy(Player p){
        despawn(p);
        NPCManager.npcList.remove(this.entityID);
    }
    @SuppressWarnings("unused")
    public void addToTablist(){
        PacketPlayOutPlayerInfo packet = new PacketPlayOutPlayerInfo();
        PacketPlayOutPlayerInfo.PlayerInfoData data = packet.new PlayerInfoData(gameprofile, 1, WorldSettings.EnumGamemode.NOT_SET, CraftChatMessage.fromString(gameprofile.getName())[0]);
        List<PacketPlayOutPlayerInfo.PlayerInfoData> players = (List<PacketPlayOutPlayerInfo.PlayerInfoData>) getValue(packet, "b");
        players.add(data);

        setValue(packet, "a", PacketPlayOutPlayerInfo.EnumPlayerInfoAction.ADD_PLAYER);
        setValue(packet, "b", players);

        sendPacket(packet);
    }

    public void rmvFromTablist(){
        PacketPlayOutPlayerInfo packet = new PacketPlayOutPlayerInfo();
        PacketPlayOutPlayerInfo.PlayerInfoData data = packet.new PlayerInfoData(gameprofile, 1, WorldSettings.EnumGamemode.NOT_SET, CraftChatMessage.fromString(gameprofile.getName())[0]);
        List<PacketPlayOutPlayerInfo.PlayerInfoData> players = (List<PacketPlayOutPlayerInfo.PlayerInfoData>) getValue(packet, "b");
        players.add(data);

        setValue(packet, "a", PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER);
        setValue(packet, "b", players);

        sendPacket(packet);
    }


    public void spawnEntity(Player p){
        GameProfile profile = this.gameprofile;
        PacketPlayOutNamedEntitySpawn packet = new PacketPlayOutNamedEntitySpawn();
        setValue(packet, "a", entityID);
        setValue(packet, "b", profile.getId());
        setValue(packet, "c", MathHelper.floor(location.getX() * 32.0D));
        setValue(packet, "d", MathHelper.floor(location.getY() * 32.0D));
        setValue(packet, "e", MathHelper.floor(location.getZ() * 32.0D));
        setValue(packet, "f", (byte) ((int) (location.getYaw() * 256.0F / 360.0F)));
        setValue(packet, "g", (byte) ((int) (location.getPitch() * 256.0F / 360.0F)));
        DataWatcher w = new DataWatcher(null);
        w.a(10,(byte)127);
        setValue(packet, "i", w);
        try {
            PacketPlayOutScoreboardTeam scbpacket = new PacketPlayOutScoreboardTeam();
            setValue(scbpacket, "h", 0);
            setValue(scbpacket, "b", profile.getName());
            setValue(scbpacket, "a", profile.getName());
            setValue(scbpacket, "e", "never");
            setValue(scbpacket, "i", 1);
            Field f = scbpacket.getClass().getDeclaredField("g");
            f.setAccessible(true);
            ( (Collection) f.get(scbpacket)).add(profile.getName());
            sendPacket(scbpacket, p);
            spawned = true;
        } catch (Exception ex) {
            ex.printStackTrace();
            spawned = false;
        }
        addToTablist();
        sendPacket(packet, p);
        PacketPlayOutEntityHeadRotation rotationpacket = new PacketPlayOutEntityHeadRotation();
        setValue(rotationpacket, "a", entityID);
        setValue(rotationpacket, "b", (byte) ((int) (location.getYaw() * 256.0F / 360.0F)));
        sendPacket(rotationpacket, p);
        Bukkit.getScheduler().runTaskLater(Bedwars.getInstance(), this::rmvFromTablist,35);
    }
}

package obed.me.bedwars.managers;

import obed.me.bedwars.Bedwars;
import obed.me.bedwars.objects.*;
import obed.me.bedwars.objects.game.Map;
import obed.me.bedwars.objects.game.Team;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.*;
import java.util.Locale;
import java.util.Objects;

public class ArenaManager {
    private final Bedwars plugin = Bedwars.getInstance();

    public void LoadMap(File file){
        //Load the map and load the config of the map.
        if(file == null)
            return;
        copyDirectory(file.getAbsolutePath(),Bukkit.getWorldContainer().getAbsolutePath());
        if(!file.isDirectory())
            return;

        for(File f1 : Objects.requireNonNull(file.listFiles())){
            if(f1.getName().startsWith("config")){
                Bukkit.createWorld(new WorldCreator(file.getName()));
                loadArenaConfig(f1);
                break;
            }
        }
    }

    private void loadArenaConfig(File f1) {
        try{
            FileConfiguration config = YamlConfiguration.loadConfiguration(f1);
            Map map = new Map();
            World world = Bukkit.getWorld(f1.getName());
            world.setFullTime(1000);
            world.setStorm(false);
            world.setThundering(false);
            map.setName(config.getString("name"));
            map.setWorld(world);
            map.setLobbyTime(plugin.getArenaConfig().getConfig().getInt("default.time.waiting"));
            map.setGameTime(plugin.getArenaConfig().getConfig().getInt("default.time.game"));
            map.setPlayersPerTeam(config.getInt("per_team_player"));
            map.setMinPlayers(config.getInt("min_players"));
            map.setMaxHeight(config.getInt("max_height"));
            map.setSpectatorLocation(getLocation(config.getString("cords.spectator")));
            map.setLobbyLocation(getLocation(config.getString("cords.lobby.center")));
            map.setLobbycord1(getLocation(config.getString("cords.lobby.corners.a")));
            map.setLobbycord2(getLocation(config.getString("cords.lobby.corners.b")));

            for(String str : config.getStringList("teams"))
                map.getTeamsList().put(str, new Team(str));
            for(String str : Objects.requireNonNull(config.getConfigurationSection("locations")).getKeys(false)){
                //str = locations.VALUE
                Team tm = map.getTeamsList().get(str);
                ConfigurationSection cfg = config.getConfigurationSection("locations." + str);
                assert cfg != null;
                tm.setSpawn(getLocation(cfg.getString("spawn")));
                LXYZ bed = new LXYZ(tm);
                bed.setCor1(getLocation(cfg.getString("bed.cor1")));
                bed.setCor1(getLocation(cfg.getString("bed.cor2")));
                tm.setBed(bed);
                tm.setColor(Color.valueOf(str.toUpperCase(Locale.ROOT)));
                tm.setDealer_location(getLocation(cfg.getString("upgrader")));
                tm.setShop_location(getLocation(cfg.getString("shop")));
                for(String strr : config.getConfigurationSection("locations."+ str + ".spawners").getKeys(true)){
                    //strr > location.value.spawners.1
                    ConfigurationSection cfgspawn = config.getConfigurationSection(strr);
                    Spawner spawner = new Spawner(strr,SpawnerType.valueOf(cfgspawn.getString("type")),
                            Objects.requireNonNull(getLocation(cfgspawn.getString("location"))));
                    spawner.setDrop_time(config.getInt("spawners_time." + spawner.getType() + ".drop_time"));
                    //los runnables se ejecutaran una vez termine el waiting time de la arena.
                    tm.getSpawners().add(spawner);
                }

            }
            for(String stg : config.getConfigurationSection("generators").getKeys(true)){
                //generators.1
                ConfigurationSection cfg = config.getConfigurationSection(stg);
                Spawner spawner = new Spawner(stg, SpawnerType.valueOf(cfg.getString("type")), Objects.requireNonNull(getLocation(cfg.getString("loc"))));
                map.getSpawnersList().add(spawner);

            }

            map.setStatus(Status.WAITING);
            plugin.setMapa(map);

            plugin.setPlayable(true);
        }catch (Exception e){
            e.printStackTrace();
            Bukkit.getLogger().severe("Error al cargar el Mapa: " + f1.getName());
            Bukkit.shutdown();
        }
    }

    private Location getLocation(String str){
        try {
            //world,x,y,z,yaw,pitch
            World world = Bukkit.getWorld(str.split(",")[0]);
            int x = Integer.parseInt(str.split(",")[1]);
            int y = Integer.parseInt(str.split(",")[2]);
            int z = Integer.parseInt(str.split(",")[3]);
            float yaw = Integer.parseInt(str.split(",")[4]);
            float pitch = Integer.parseInt(str.split(",")[5]);
            return new Location(world,x,y,z,yaw,pitch);
        }catch (Exception e){
            return null;
        }
    }
    /**
     * Copiar un directorio y todo su contenido de forma recursiva
     * @param org
     * @param dest
     */
    private void copyDirectory(String org, String dest) {
        checkCreated(dest);
        File directorio = new File(org);
        File f;
        if (directorio.isDirectory()) {
            checkCreated(dest);
            String [] files = directorio.list();
            if (files.length > 0) {
                for (String archivo : files) {
                    f = new File (org + File.separator + archivo);
                    if(f.isDirectory()) {
                        checkCreated(dest+File.separator+archivo+File.separator);
                        copyDirectory(org+File.separator+archivo+File.separator, dest+File.separator+archivo+File.separator);
                    } else { //Es un archivo
                        copyFile(org+File.separator+archivo, dest+File.separator+archivo);
                    }
                }
            }
        }
    }

    /**
     * Copia el archivo origen en el destino
     * @param sOrigen
     * @param sDestino
     */
    private void copyFile(String sOrigen, String sDestino) {
        try {
            File origen = new File(sOrigen);
            File destino = new File(sDestino);
            InputStream in = new FileInputStream(origen);
            OutputStream out = new FileOutputStream(destino);

            byte[] buf = new byte[1024];
            int len;

            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }

            in.close();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Comprueba si un directorio existe, y en caso contrario crea toda la ruta necesaria para que exista
     * @param ruta
     */
    private void checkCreated(String ruta) {
        File directorio = new File(ruta);
        if (!directorio.exists()) {
            directorio.mkdirs();
        }
    }
}

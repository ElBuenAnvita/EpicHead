package obed.me.bedwars.utils;

import net.minecraft.server.v1_8_R3.PacketPlayOutScoreboardTeam;
import net.minecraft.server.v1_8_R3.ScoreboardTeam;
import net.minecraft.server.v1_8_R3.ScoreboardTeamBase;
import obed.me.bedwars.Bedwars;
import obed.me.bedwars.objects.game.Team;
import obed.me.bedwars.objects.game.User;
import obed.me.bedwars.utils.nms.NMSUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_8_R3.scoreboard.CraftScoreboard;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;

public class HidePlayerUtil {

    public static void hideArmor(Player p){
        //runnable to send packet every tick
        new BukkitRunnable(){

            @Override
            public void run() {
                if(p == null){
                    cancel();
                    return;
                }
                if(p.isDead() || !p.hasPotionEffect(PotionEffectType.INVISIBILITY)){
                    setArmor(p);
                    cancel();
                    return;
                }
                HidePlayerTagName(p, true);
                NMSUtil.getNMS().HideArmor(p, 1, new ItemStack(Material.AIR));
                NMSUtil.getNMS().HideArmor(p, 2, new ItemStack(Material.AIR));
                NMSUtil.getNMS().HideArmor(p, 3, new ItemStack(Material.AIR));
                NMSUtil.getNMS().HideArmor(p, 4, new ItemStack(Material.AIR));
            }
        }.runTaskTimerAsynchronously(Bedwars.getInstance(), 20, 0);
    }

    public static void setArmor(Player p ){
        HidePlayerTagName(p, false);
        NMSUtil.getNMS().HideArmor(p, 1, p.getInventory().getHelmet());
        NMSUtil.getNMS().HideArmor(p, 2, p.getInventory().getChestplate());
        NMSUtil.getNMS().HideArmor(p, 3, p.getInventory().getLeggings());
        NMSUtil.getNMS().HideArmor(p, 4, p.getInventory().getBoots());
    }

    public static void HidePlayerTagName(Player target, boolean bol){
        // Get the remaining teams on the game
        User user = User.getUser(target);
        for(Team team : Bedwars.getInstance().getMapa().getTeamRemining()){
            //Check if the team is not the same as the target, so his team always see his name.
            if(team == user.getTeam())
                return;
            //Get all the players in each team.
            team.getPlayers().forEach(player -> {
                Player p = player.getPlayer();
                // Get the scoreboardTeam with NMS (Not Reflection)
                ScoreboardTeam scoreboardTeam = new ScoreboardTeam(((CraftScoreboard) Bukkit.getScoreboardManager().getMainScoreboard()).getHandle(), p.getName());

                //Setting the team color to the scoreboard prefix.
                //For versions 1.13+ use: scoreboardTeam#setColor();
                scoreboardTeam.setPrefix(team.getColor().getChatColor() + "");
                //Show or Hide the NameTagVisibility
                scoreboardTeam.setNameTagVisibility(bol ? ScoreboardTeamBase.EnumNameTagVisibility.NEVER : ScoreboardTeamBase.EnumNameTagVisibility.ALWAYS);
                //Rewriting the PlayerListName Color for the player.
                //Without this, the player will have a blank nametag after sending the packets.
                p.setPlayerListName(team.getColor().getChatColor() + p.getName());

                ArrayList<String> playerToAdd = new ArrayList<>();
                playerToAdd.add(target.getName()); //Add the target to the list, so this target will not have a nametag
                ((CraftPlayer)p).getHandle().playerConnection.sendPacket(new PacketPlayOutScoreboardTeam(scoreboardTeam, 1));
                ((CraftPlayer)p).getHandle().playerConnection.sendPacket(new PacketPlayOutScoreboardTeam(scoreboardTeam, 0));
                ((CraftPlayer)p).getHandle().playerConnection.sendPacket(new PacketPlayOutScoreboardTeam(scoreboardTeam, playerToAdd, 3));
            });

        }

    }



}

package obed.me.bedwars.objects;

public class SType {   /*
 * TODO:
 *  items specials:
 * TNT
 * RASTREADOR
 * BOLA DE FUEGO
 * GOLEM
 * EGG
 * TOWER
 * SPONGE
 * SILVERFISH
 *
 */
}

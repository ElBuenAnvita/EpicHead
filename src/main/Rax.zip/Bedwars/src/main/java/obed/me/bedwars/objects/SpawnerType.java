package obed.me.bedwars.objects;

import org.bukkit.ChatColor;
import org.bukkit.Material;

public enum SpawnerType {
    DIAMOND(Material.DIAMOND, Material.DIAMOND_BLOCK, ChatColor.AQUA + "Diamante"),
    EMERALD(Material.EMERALD, Material.EMERALD_BLOCK, ChatColor.GREEN + "Esmeralda"),
    IRON(Material.IRON_INGOT, Material.IRON_BLOCK, "TEAM"),
    GOLD(Material.GOLD_INGOT,Material.GOLD_BLOCK, "TEAM");

    private Material droptype;
    private Material blockType;
    private String name;

    SpawnerType(Material Droptype, Material BlockType, String name) {
        this.name = name;
        this.droptype = Droptype;
        this.blockType = BlockType;
    }

    public Material getDroptype() {
        return droptype;
    }

    public void setDroptype(Material droptype) {
        this.droptype = droptype;
    }

    public Material getBlockType() {
        return blockType;
    }

    public void setBlockType(Material blockType) {
        this.blockType = blockType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

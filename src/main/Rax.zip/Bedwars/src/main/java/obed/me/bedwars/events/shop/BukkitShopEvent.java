package obed.me.bedwars.events.shop;

import obed.me.bedwars.objects.game.User;
import obed.me.bedwars.objects.shop.SItem;
import obed.me.bedwars.utils.ComparatorUtil;
import obed.me.bedwars.utils.ItemUtil;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

import static obed.me.bedwars.objects.shop.ShopInventory.autoWear;

public class BukkitShopEvent implements Listener {
    @EventHandler
    public void ShopEvent(UserBuyItemEvent e){
        Player p = e.getUser().getPlayer();
        if (e.isCancelled()) {
            p.sendMessage(e.getResult().toString());
            return;
        }
       else { if (!e.getCategory().isLeveling()) {
            if (e.getItem().isAutoWear()) autoWear(p, e.getItem());
            else e.getItem().getContent().forEach(i -> p.getInventory().addItem(ItemUtil.addDealerEnchantment(i,e.getUser().getTeam())));
        }
            //before is the previously item on the leveling category.
            //rule: when a category is leveling, the content must be just one item.
            ItemStack before = null;
            try{before = e.getItem().getLevelCategory().getLeveling_list().get(e.getItem().getLevel()-1).getContent().get(0);}catch (Exception ignored){}
            if (e.getItem().isAutoWear()) autoWear(p, e.getItem());
            else {
                int x = 0;
                boolean contains = false;
                if(before != null){
                    for (ItemStack itm : p.getInventory().getContents()) {
                        if (itm == null){
                            x++;
                            continue;
                        }
                        if (itm.getType() == Material.AIR) {
                            x++;
                            continue;
                        }
                        if (itm.getType() == before.getType()) {
                            contains = true;
                            p.getInventory().setItem(x, ItemUtil.addDealerEnchantment(e.getItem().getContent().get(0), e.getUser().getTeam()));
                            break;
                        }
                        x++;
                    }
                }
                if(!contains)
                    p.getInventory().addItem(ItemUtil.addDealerEnchantment(e.getItem().getContent().get(0), e.getUser().getTeam()));
            }
        }
        p.playSound(p.getLocation(), Sound.ITEM_PICKUP, Float.MAX_VALUE, Float.MAX_VALUE);
        p.updateInventory();
    }
    /*
        TODO:
        - remove dropped item if its the first on the leveling.
     */
    @EventHandler
    public void PlayerDeadEvent(PlayerDeathEvent e){
        User user = User.getUser(e.getEntity());
        for(List<SItem> items : user.getBuyedItems().values())
            items.removeIf(sItem -> !sItem.isKeepInventory());

        for(SItem categories : user.getBuyedItems().keySet()){
            if(!(categories.isLeveling() || categories.getCategory().isLeveling()))
                continue;
            //is leveling on
            user.getBuyedItems().get(categories).sort(new ComparatorUtil());
            //item is the max exponent level in your bought list, its 0 cause always the list is cleaning when adding new item.
            SItem item = user.getBuyedItems().get(categories).get(0);
            for(SItem content : item.getLevelCategory().getLeveling_list().values()){

                if(item.getLevel() -1 == content.getLevel()){
                    //this is the new item for the user, if not exits would be the same as bought.
                    item = content;
                    break;
                }
            }
            user.getBuyedItems().get(categories).clear();
            user.getBuyedItems().get(categories).add(item);
        }


    }


    @EventHandler
    public void PlayerRespawn(PlayerRespawnEvent e){
        User user = User.getUser(e.getPlayer());
        for(List<SItem> items : user.getBuyedItems().values()){
            items.forEach(sItem ->{
                if(sItem.isAutoWear()) autoWear(e.getPlayer(), sItem);
                else sItem.getContent().forEach(i->e.getPlayer().getInventory().addItem(ItemUtil.addDealerEnchantment(i, User.getUser(e.getPlayer()).getTeam())));
            });
        }
    }
}

package obed.me.bedwars.utils.reflect;
import org.bukkit.event.block.Action;

public enum ClickType {
    LEFT, RIGHT, SHIFT_LEFT, SHIFT_RIGHT;

    public static ClickType fromAction(Action action, boolean sneak) {
        switch (action) {
            case LEFT_CLICK_BLOCK:
            case LEFT_CLICK_AIR:
                return sneak ? SHIFT_LEFT : LEFT;
            case RIGHT_CLICK_BLOCK:
            case RIGHT_CLICK_AIR:
                return sneak ? SHIFT_RIGHT : RIGHT;
        }
        return null;
    }

    public static ClickType fromString(String string) {
        switch (string) {
            case "LEFT":
                return LEFT;
            case "SHIFT_LEFT":
                return SHIFT_LEFT;
            case "RIGHT":
                return RIGHT;
            case "SHIFT_RIGHT":
                return SHIFT_RIGHT;
        }
        return null;
    }
}
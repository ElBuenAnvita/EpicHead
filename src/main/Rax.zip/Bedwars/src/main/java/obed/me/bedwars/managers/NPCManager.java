package obed.me.bedwars.managers;

import lombok.Getter;
import lombok.Setter;
import obed.me.bedwars.Bedwars;
import obed.me.bedwars.objects.NPC;
import obed.me.bedwars.objects.shop.TypeInventory;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.HashMap;
@Getter
@Setter
public class NPCManager {
    public static final HashMap<Integer, NPC> npcList = new HashMap<>();

    public static NPC getNPC(int id){
        if(npcList.containsKey(id))
            return npcList.get(id);
        return null;
    }

    public static NPC createNPC(String name, Location loc, TypeInventory type){
        NPC npc = new NPC(name,loc);
        npc.setTypeInventory(type);
        Bukkit.getOnlinePlayers().forEach(npc::spawnEntity);
        return npc;
    }

    public static void initFollowNPC(){
        Bukkit.getScheduler().runTaskTimerAsynchronously(Bedwars.getInstance(),()->{
            for(NPC ent : npcList.values())
                if(ent.isSpawned()) ent.follow();
        },0,1L);
    }

    public static void renderNPCs(){
        Bukkit.getScheduler().runTaskTimerAsynchronously(Bedwars.getInstance(), ()->{
            for(NPC ent : npcList.values()){
                for(Player p : Bukkit.getOnlinePlayers()){
                    double distance = ent.getLocation().distance(p.getLocation());
                    if(distance > 60)
                        ent.despawn(p);
                    else if(distance < 60 && !ent.isSpawned())
                        ent.spawnEntity(p);
                }
            }
        },0,60L);
    }

}

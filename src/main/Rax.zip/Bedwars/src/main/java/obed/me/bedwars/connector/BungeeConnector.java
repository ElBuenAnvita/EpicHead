package obed.me.bedwars.connector;

public class BungeeConnector {
}

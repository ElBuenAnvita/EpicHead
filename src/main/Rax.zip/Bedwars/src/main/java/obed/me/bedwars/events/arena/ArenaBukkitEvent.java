package obed.me.bedwars.events.arena;

import obed.me.bedwars.Bedwars;
import obed.me.bedwars.objects.*;
import obed.me.bedwars.objects.game.Map;
import obed.me.bedwars.objects.game.Team;
import obed.me.bedwars.objects.game.User;
import obed.me.bedwars.utils.ItemUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

public class ArenaBukkitEvent implements Listener {
    private final Map map = Bedwars.getInstance().getMapa();

    @EventHandler
    public void cancelingEvents(PlayerBedEnterEvent a, FoodLevelChangeEvent b, BlockSpreadEvent c, BlockBurnEvent d, WeatherChangeEvent e){
        a.setCancelled(true);
        b.setCancelled(true);
        c.setCancelled(true);
        d.setCancelled(true);
        e.setCancelled(true);
    }
    @EventHandler
    public void PlayerDropItemEvent(PlayerDropItemEvent e){
        User user = User.getUser(e.getPlayer());
        if(map.getStatus() == Status.WAITING){
            e.setCancelled(true);
            return;
        }
        if (e.getPlayer().getLocation().getBlock().getRelative(BlockFace.DOWN).getType() == Material.AIR)
            e.setCancelled(true);

        if(user.getTeam() == null)
            e.setCancelled(true);
    }

    @EventHandler
    public void PlayerBlockPlaceEvent(BlockPlaceEvent e){
        User user = User.getUser(e.getPlayer());
        if(map.getStatus() != Status.GAME)
            e.setCancelled(true);

        if(user.getTeam() == null)
            e.setCancelled(true);

        e.getBlock().setMetadata("Breakable", new FixedMetadataValue(Bedwars.getInstance(), true));

    }

    @EventHandler
    public void BlockBreakEvent(BlockBreakEvent e){
        if(map.getStatus() != Status.GAME)
            e.setCancelled(true);

        if(e.getBlock().getType() == Material.BED_BLOCK)
            return;

        if(!e.getBlock().hasMetadata("Breakable"))
            e.setCancelled(true);
    }
    @EventHandler
    public void BlockExplode(BlockExplodeEvent e){
        e.blockList().removeIf(block1 -> !block1.hasMetadata("Breakable"));
        e.blockList().removeIf(block1 -> block1.getType().isTransparent());
    }

    @EventHandler
    public void PlayerPickupItemEvent(PlayerPickupItemEvent e){
        User user = User.getUser(e.getPlayer());
        if(user.getTeam() == null)
            e.setCancelled(true);

        ItemStack item = e.getItem().getItemStack();
        if(ItemUtil.getNBTTag(item, "spawner-drop") == null) return;
        String tag = ItemUtil.getNBTTag(item, "spawner-drop");
        if(!tag.equalsIgnoreCase("TEAM")) return;

        ItemStack clItem = ItemUtil.removeNBTag(item);
        e.setCancelled(true);
        e.getItem().getLocation().getWorld().getNearbyEntities(
                e.getItem().getLocation(),3,4,3
        ).forEach(entity ->
        {
            if(entity instanceof Player){
                ((Player) entity).getInventory().addItem(clItem);
                //event here.
            }
        });

    }
    @EventHandler
    public void PlayerPreLoginEvent(AsyncPlayerPreLoginEvent e){
        if(!Bedwars.getInstance().isPlayable())
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, "la arena aun no está disponible.");

        if(map.getStatus() == Status.GAME) e.allow(); //spectator join
        if(map.getStatus() == Status.FINISH)
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, "La arena no está disponible.");
        if(map.getPlayers().size() == map.getMaxPlayers())
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_FULL, "La arena está completa.");
    }

    @EventHandler
    public void BedBreakEvent(BlockBreakEvent e){
        User user = User.getUser(e.getPlayer());
        if(e.getBlock().getType() != Material.BED_BLOCK)
            return;
        Location a,b = null;
        a = e.getBlock().getLocation();
        for(BlockFace v : LXYZ.getBlockFaceList()){
            if(e.getBlock().getRelative(v).getType() == Material.BED_BLOCK)
                b =  e.getBlock().getRelative(v).getLocation();
        }
        for(Team team : map.getTeamRemining()){
            LXYZ bed = team.getBed();
            if(bed.getCor1() == a && bed.getCor2() == b || bed.getCor1() == b && bed.getCor2() == a){
                if(user.getTeam() == team){
                    //you cant destroy your own bed.
                    e.setCancelled(true);
                    return;
                }
                e.getBlock().getDrops().clear();
                team.setBedDestroy(true);
                //UserDestroyBedEvent

            }
        }

    }

    @EventHandler
    public void InteractEvent(PlayerInteractAtEntityEvent e){
        if(e.getRightClicked() instanceof Player){
            return;
        }
        if(e.getRightClicked().getCustomName().equalsIgnoreCase("config.shop")){
            //open shop here.
            return;
        }
        if(e.getRightClicked().getCustomName().equalsIgnoreCase("config.dealer")){
            //open dealer here.
            return;
        }


    }

    @EventHandler
    public void PlayerLeaveEvent(PlayerQuitEvent e){
        e.setQuitMessage(null);
        //get the last damage and check if its a player.

    }

    @EventHandler
    public void WeatherChangeEvent(WeatherChangeEvent e){
        e.setCancelled(true);
    }
    @EventHandler
    public void spawnEntity(CreatureSpawnEvent e){
        if(e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.NATURAL){
            e.getEntity().remove();
            e.setCancelled(true);
        }
    }
    @EventHandler
    public void PlayerJoinEvent(PlayerJoinEvent e){
        e.setJoinMessage(null);
      if(map.getStatus() == Status.GAME){
          if(map.getPlayerTeam(e.getPlayer()) == null){
              //is spectator event.
              return;
          }
          //player join again to the game as if died.
          map.getPlayers().add(new User(e.getPlayer()));

        return;
      }
      if(map.getStatus() == Status.WAITING){
          if(!map.isStarted()){
              if(map.getPlayers().size() >= map.getMinPlayers()){
                  map.setStarted(true);
                  map.run();
              }
          }
          //UserJoinArenaEvent(); in waiting time.
      }
    }
}

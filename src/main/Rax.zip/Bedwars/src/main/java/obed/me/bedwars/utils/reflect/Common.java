package obed.me.bedwars.utils.reflect;

import java.util.List;
import java.util.logging.Level;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

public final class Common {
    private Common() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    private static final Pattern SPACING_CHARS_REGEX = Pattern.compile("[_ \\-]+");

    public static final Version SERVER_VERSION = Version.valueOf(ReflectionUtil.getVersion());

    public static String PREFIX = "[RotatingHeads] ";

    public static String colorize(String string) {
        return ChatColor.translateAlternateColorCodes('&', string);
    }

    public static List<String> colorize(List<String> list) {
        list.replaceAll(Common::colorize);
        return list;
    }

    public static String stripColors(String string) {
        return ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&',string));
    }

    public static void log(String message) {
        log(Level.INFO, message);
    }

    public static void log(String message, Object... args) {
        log(String.format(message, args));
    }

    public static void log(Level level, String message) {
        Bukkit.getServer().getLogger().log(level, "[RotatingHeads] " + message);
    }

    public static void log(Level level, String message, Object... args) {
        log(level, String.format(message, args));
    }

    public static void debug(Object o) {
        System.out.println(o);
    }

    public static void tell(CommandSender player, String message) {
        player.sendMessage(colorize(message));
    }

    public static void tell(CommandSender player, String message, Object... args) {
        tell(player, String.format(message, args));
    }

    public static String removeSpacingChars(String string) {
        return SPACING_CHARS_REGEX.matcher(string).replaceAll("");
    }

    private static int[] splitVersion(String version) {
        String[] spl = (version == null) ? null : version.split("\\.");
        if (spl == null || spl.length < 3)
            return new int[0];
        int[] arr = new int[spl.length];
        for (int i = 0; i < spl.length; i++)
            arr[i] = parseInt(spl[i]);
        return arr;
    }

    private static int parseInt(String string) {
        try {
            return Integer.parseInt(string);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static boolean isPluginEnabled(String name) {
        return Bukkit.getPluginManager().isPluginEnabled(name);
    }
}
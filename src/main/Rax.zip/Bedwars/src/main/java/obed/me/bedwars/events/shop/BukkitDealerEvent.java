package obed.me.bedwars.events.shop;

import obed.me.bedwars.Bedwars;
import obed.me.bedwars.objects.game.Team;
import obed.me.bedwars.objects.game.User;
import obed.me.bedwars.utils.ItemUtil;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class BukkitDealerEvent implements Listener {
    /*
    TODO:
        - Cambiar la speed de los generadores de isla a double y revisar su funcionamiento,
        revisar las variables doubles en encantamientos.
        - añadir sonidos, mensajes, etc.
     */
    @EventHandler
    public void DealerBuyItemEvent(UserBuyDealerEvent e){
        if(e.isCancelled()){
            e.getUser().getPlayer().sendMessage(e.getReason().toString());
            return;
        }
        User user = e.getUser();
        Team team = e.getTeam();
        //the player can buy.
        e.getUser().getTeam().getDealers().put(e.getDItem().getIdentifier(), e.getDItem());
        switch (e.getDItem().getDealerItemType()){
            case DEALER_SHARPNESS:
                team.getPlayers().forEach(user1 -> {
                    for(ItemStack item : user1.getPlayer().getInventory()){
                        if(item.getType().toString().contains("SWORD"))
                            item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, (int) e.getDItem().getEnchLevel());
                    }
                    user1.getPlayer().updateInventory();
                });
                break;
            case DEALER_PROTECTION:
                team.getPlayers().forEach(user1 -> {
                    for(ItemStack item : user1.getPlayer().getInventory().getArmorContents())
                        item.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, (int) e.getDItem().getEnchLevel());
                    user1.getPlayer().updateInventory();
                });
                break;
            case DEALER_MINER:
                team.getPlayers().forEach(user1 -> {
                    for(ItemStack item : user1.getPlayer().getInventory()){
                        if(item.getType().toString().contains("AXE") || item.getType().toString().contains("PICKAXE"))
                            item.addUnsafeEnchantment(Enchantment.DIG_SPEED, (int) e.getDItem().getEnchLevel());
                    }
                    user1.getPlayer().updateInventory();
                });
                break;
            case DEALER_GENERATOR:
                team.getSpawners().forEach(spawner -> {
                    spawner.setDrop_time((int)(spawner.getDrop_time() * e.getDItem().getEnchLevel()));
                });
                break;
            case DEALER_HEALER:
                team.getPlayers().forEach(user1 -> {
                    user1.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.HEAL,10*20,(int)e.getDItem().getEnchLevel(),true));
                });
                break;
            case DEALER_ALARM:
                new BukkitRunnable(){
                    @Override
                    public void run() {
                        for(User users : Bedwars.getInstance().getMapa().getPlayers()){
                            if(team == users.getTeam())
                                continue;
                            if(!team.getIsland().contains(users.getPlayer().getLocation()))
                                continue;
                            team.getPlayers().forEach(p->{
                                p.getPlayer().playSound(p.getPlayer().getLocation(), Sound.ENDERMAN_TELEPORT,Float.MAX_VALUE,Float.MAX_VALUE);
                                //send chat message, send tittle.
                                p.getPlayer().sendMessage("Trampa desactivada por " + users.getPlayer().getName());
                            });
                            //remover el item comprado.
                            e.getUser().getTeam().getDealers().remove(e.getDItem().getIdentifier(), e.getDItem());
                            cancel();
                            break;

                        }
                    }
                }.runTaskTimerAsynchronously(Bedwars.getInstance(),0,20L);
                break;
            case DEALER_DRAGON:
                team.setDragons(team.getDragons()+1);
                //message here
                break;
        }
    }
}

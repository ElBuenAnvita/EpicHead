package obed.me.bedwars.objects;

import lombok.Getter;
import lombok.Setter;
import org.bukkit.Location;

@Getter
@Setter
public class ZoneCuboid {
    private ZoneVector min;
    private ZoneVector max;
    public ZoneCuboid(ZoneVector min, ZoneVector max){
        this.min = min;
        this.max = max;
    }

    public boolean contains(Location loc){
        ZoneVector curr = new ZoneVector(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        ZoneVector minV = new ZoneVector(Math.min(min.getX(), max.getX()), Math.min(min.getY(), max.getY()), Math.min(min.getZ(), max.getZ()));
        ZoneVector maxV = new ZoneVector(Math.max(min.getX(), max.getX()), Math.max(min.getY(), max.getY()), Math.max(min.getZ(), max.getZ()));
        return curr.isInAABB(minV, maxV);
    }

    public ZoneVector getMiddleZoneVector() {
        return new ZoneVector(((min.getX() + max.getX())/2), ((min.getY() + max.getY())/2), ((min.getZ() + max.getZ())/2));
    }
}


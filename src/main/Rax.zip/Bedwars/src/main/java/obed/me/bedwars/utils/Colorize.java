package obed.me.bedwars.utils;

import org.bukkit.ChatColor;

import java.util.ArrayList;
import java.util.List;

public class Colorize {

    public static String toColor(String str){
        return ChatColor.translateAlternateColorCodes('&', str);
    }

    public static String strip(String str){
        return ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&', str));
    }

    public static List<String> toColor(List<String> str){
        List<String> list = new ArrayList<>();
        for(String ls : str){
            list.add(toColor(ls));
        }
        return list;
    }
}

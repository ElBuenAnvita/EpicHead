package obed.me.bedwars.utils;

public class Particles {
}

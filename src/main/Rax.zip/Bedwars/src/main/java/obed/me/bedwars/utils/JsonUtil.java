package obed.me.bedwars.utils;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.stream.IntStream;

public class JsonUtil {
    private static HttpURLConnection conn;

    private static JSONArray call(String value){
        BufferedReader reader;
        String line;
        StringBuilder responseContent = new StringBuilder();
        try{
            URL url = new URL(value);
            conn = (HttpURLConnection) url.openConnection();
            // Request setup
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);// 5000 milliseconds = 5 seconds
            conn.setReadTimeout(5000);

            // Test if the response from the server is successful
            int status = conn.getResponseCode();

            if (status >= 300)
                reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            else
                reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = reader.readLine()) != null)
                responseContent.append(line);
            reader.close();
            responseContent.insert(responseContent.length(),"]");
            responseContent.insert(0,"[");
           return new JSONArray(responseContent.toString());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            conn.disconnect();
        }
    }

    public static String getPlayerUUID(String name){
        JSONArray jsonArray = call("https://api.mojang.com/users/profiles/minecraft/" + name);
        return jsonArray != null ? getKey(jsonArray,"id") : null;
    }

    public static JSONArray getProfileData(String uuid){
        JSONArray array = call("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid +"?unsigned=false");
        return array != null ? new JSONArray(array.getJSONObject(0).get("properties").toString()) : null;
    }
    public static String getKey(JSONArray array, String key) {
        return IntStream.range(0, array.length()).mapToObj(array::getJSONObject).findFirst().map(object -> object.getString(key)).orElse(null);
    }

}

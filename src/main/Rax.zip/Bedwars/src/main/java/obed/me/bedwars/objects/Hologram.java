package obed.me.bedwars.objects;

import obed.me.bedwars.Bedwars;
import obed.me.bedwars.utils.Colorize;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

public class Hologram {
    private final List<String> lines;
    private final List<ArmorStand> entities = new ArrayList<>();
    private double space;
    private Location location;

    public Hologram(Location loc, List<String> lines, double space) {
        this.location = loc;
        this.lines = lines;
        this.space = space;

        for (String ignored : lines)
            this.entities.add(location.getWorld().spawn(loc, ArmorStand.class));

        for(ArmorStand arm : entities){
            arm.setGravity(false);
            arm.setVelocity(new Vector(0,0,0));
            arm.setVisible(false);
            arm.setBasePlate(false);
            arm.setArms(false);
            arm.setMarker(false);
            arm.setCanPickupItems(false);
            arm.setRemoveWhenFarAway(false);
            arm.setCustomNameVisible(true);
        }
        Bedwars.getInstance().getServer().getScheduler().runTaskLater(Bedwars.getInstance(), ()->{
            Location origin = this.location.clone();
            origin.add(0.0D, this.space * this.lines.size(), 0.0D);
            int id = 0;
            for(String ignored : lines){
                ArmorStand arm = entities.get(id);
                arm.setCustomName(Colorize.toColor(ignored));
                arm.teleport(origin);
                origin.subtract(0.0D, this.space, 0.0D);
                id++;
            }

        },2L);
    }
    public void setSpace(double a){
        this.space = a;
    }
    public double getSpace(){return this.space;}
    public void destroy() {
        for(ArmorStand ent : entities)
            ent.remove();
    }

    public void update(List<String> lines) {
        try {
            int id = 0;
            for (String line : lines) {
                entities.get(id).setCustomName(ChatColor.translateAlternateColorCodes('&', line));
                id++;
            }
        } catch (Exception ignored) {}
    }

    public Location getLoc() {
        return location;
    }

    public void setLoc(Location loc) {
        this.location = loc;
    }

}

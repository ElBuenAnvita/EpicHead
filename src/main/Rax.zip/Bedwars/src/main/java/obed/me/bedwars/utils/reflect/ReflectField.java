package obed.me.bedwars.utils.reflect;

import java.lang.reflect.Field;

public class ReflectField<T> {
    private final Class<?> clazz;

    private final String name;

    private Field field;

    public ReflectField(Class<?> clazz, String name) {
        this.clazz = clazz;
        this.name = name;
    }

    private void init() throws Exception {
        if (this.field == null) {
            this.field = this.clazz.getDeclaredField(this.name);
            this.field.setAccessible(true);
        }
    }

    public T getValue(Object object) {
        try {
            if (this.field == null)
                init();
            return (T)this.field.get(object);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setValue(Object object, Object value) {
        try {
            if (this.field == null)
                init();
            this.field.set(object, value);
        } catch (Exception exception) {}
    }
}

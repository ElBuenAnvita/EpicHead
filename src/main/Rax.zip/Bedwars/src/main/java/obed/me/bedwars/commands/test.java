package obed.me.bedwars.commands;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import net.minecraft.server.v1_8_R3.*;
import obed.me.bedwars.Bedwars;
import obed.me.bedwars.objects.NPC;
import obed.me.bedwars.objects.shop.TypeInventory;
import obed.me.bedwars.utils.JsonUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.json.JSONArray;

import java.util.UUID;

public class test implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        NPC npc = new NPC(args[0], ((Player) sender).getLocation());
        npc.setSkin(args[1]);
        npc.setDisplayName("&6Tienda\n&eClick para abrir!");
        npc.setTypeInventory(TypeInventory.SHOP);
        npc.spawnEntity(((Player) sender));
        return false;
    }

}

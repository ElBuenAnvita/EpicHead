package obed.me.bedwars.events.shop;

public enum CancelledDealerReason {
    NOT_ENOUGH_ITEMS,
    NOT_ENOUGH_SPACE,
    BOUGHT,
    MAX_LEVEL
}

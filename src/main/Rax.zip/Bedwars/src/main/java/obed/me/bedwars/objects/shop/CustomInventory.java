package obed.me.bedwars.objects.shop;

import org.bukkit.entity.Player;

public abstract class CustomInventory {
    public abstract void openInventory(Player p);
    public abstract void loadInventoryData();
    public abstract TypeInventory getType();
}

package obed.me.bedwars.config;

import obed.me.bedwars.Bedwars;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

public class Cfg_Lobby extends CfgManager{
    private final Bedwars plugin = Bedwars.getInstance();
    private File configFile;
    private FileConfiguration config;
    /**
     * Method that return the config object
     * @return FileConfiguration
     */
    @Override
    public FileConfiguration getConfig() {
        if (this.config == null)
            reloadConfig();
        return this.config;
    }
    /**
     * Public method to reload the config.yml file
     */
    @Override
    public void reloadConfig() {
        if (this.config == null) {
            String path = plugin.getDataFolder().getPath()+ "/";
            String directory = path.concat("config");
            File direc = new File(directory);
            if(!direc.exists())
                direc.mkdirs();
            this.configFile =  new File(directory + "/" + "config_lobby" + ".yml");
        }
        this.config = YamlConfiguration.loadConfiguration(this.configFile);
        Reader defConfigStream = new InputStreamReader(this.plugin.getResource("config/" + "config_lobby" + ".yml"), StandardCharsets.UTF_8);
        YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(defConfigStream);
        this.config.setDefaults(defConfig);
    }


    /**
     * Register a new Config.yml File
     */
    @Override
    public void registerConfig() {

        String path = plugin.getDataFolder().getPath()+ "/";
        String directory = path.concat("config");
        File direc = new File(directory);
        if(!direc.exists())
            direc.mkdirs();
        configFile = new File(directory + "/" + "config_lobby" + ".yml");
        if(!configFile.exists()){
            try {
                configFile.createNewFile();
                config = YamlConfiguration.loadConfiguration(configFile);
                Reader defConfigStream = new InputStreamReader(this.plugin.getResource("config/" + "config_lobby" + ".yml"), StandardCharsets.UTF_8);
                YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(defConfigStream);
                config.setDefaults(defConfig);
                config.options().copyDefaults(true);
                config.save(configFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

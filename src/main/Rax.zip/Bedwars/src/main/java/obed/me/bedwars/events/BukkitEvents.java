package obed.me.bedwars.events;

public class BukkitEvents {
}

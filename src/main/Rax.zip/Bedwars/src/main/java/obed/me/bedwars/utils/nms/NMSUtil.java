package obed.me.bedwars.utils.nms;

import org.bukkit.Bukkit;

public class NMSUtil {
    private static INMS nms;
    public static void setupNMS(){
        String version = Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3];
        switch (version) {
            case "v1_8_R1":
            case "v1_8_R2":
            case "v1_8_R3":
                nms = new v1_8NMS();
                break;
            default:
                nms = new v1_13NMS();
                break;
        }
    }
    public static INMS getNMS()
    {
        return nms;
    }
}

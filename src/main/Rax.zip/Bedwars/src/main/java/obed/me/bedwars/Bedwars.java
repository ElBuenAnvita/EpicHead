package obed.me.bedwars;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.ListenerPriority;
import lombok.Getter;
import lombok.Setter;
import obed.me.bedwars.commands.test;
import obed.me.bedwars.config.Cfg_Arena;
import obed.me.bedwars.config.Cfg_Dealer;
import obed.me.bedwars.config.Cfg_Shop;
import obed.me.bedwars.events.arena.WorldEventManager;
import obed.me.bedwars.events.npc.HandlerNPC;
import obed.me.bedwars.events.shop.BukkitShopEvent;
import obed.me.bedwars.events.testing;
import obed.me.bedwars.managers.ArenaManager;
import obed.me.bedwars.managers.NPCManager;
import obed.me.bedwars.objects.game.Map;
import obed.me.bedwars.objects.Spawner;
import obed.me.bedwars.objects.SpawnerType;
import obed.me.bedwars.objects.shop.ShopInventory;
import obed.me.bedwars.utils.nms.NMS;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;
import team.unnamed.gui.MenuListeners;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public final class Bedwars extends JavaPlugin {
    private Map mapa;
    private File MapDirectory;
    private boolean playable,creatorMode, isLobby;
    private static Bedwars instance;
    private final ArenaManager arenaManager = new ArenaManager();
    private final Cfg_Arena arenaConfig = new Cfg_Arena();
    private final Cfg_Shop cfgShop = new Cfg_Shop();
    private final Cfg_Dealer cfgDealer = new Cfg_Dealer();
    public static Bedwars getInstance() {
        return instance;
    }
    private static ProtocolManager protocolManager;
    public static List<Spawner> spawnerList = new ArrayList<>();
    public ShopInventory shopInventory;
    public void onLoad() {
        protocolManager = ProtocolLibrary.getProtocolManager();
    }

    @Override
    public void onEnable() {
        instance = this;
        NMS.init();
        cfgShop.registerConfig();
        cfgShop.reloadConfig();
        shopInventory = new ShopInventory();
        shopInventory.loadInventoryData();
        protocolManager = ProtocolLibrary.getProtocolManager();
        NPCManager.initFollowNPC();
        NPCManager.renderNPCs();
        Bukkit.getWorld("world").setFullTime(1000);
        Bukkit.getWorld("world").setThundering(false);
        Bukkit.getWorld("world").setStorm(false);
        Bukkit.getPluginManager().registerEvents(new testing(), this);
        Bukkit.getPluginManager().registerEvents(new MenuListeners(), this);
        Bukkit.getPluginManager().registerEvents(new BukkitShopEvent(), this);
        Bukkit.getPluginManager().registerEvents(new WorldEventManager(), this);
        getCommand("test").setExecutor(new test());
        protocolManager.addPacketListener(new HandlerNPC(this, ListenerPriority.NORMAL, PacketType.Play.Client.USE_ENTITY));
    }

    public void loadGenerators(){
        Location loc1 = new Location(Bukkit.getWorld("world"), -2.5,71,-4.5);
        spawnerList.add(new Spawner(loc1.toString(), SpawnerType.DIAMOND,loc1));
        //se debe cargar el chunk del location para que aparezcan los armorstand.
        Bukkit.getScheduler().runTaskTimer(this,()->{
            for(Spawner spawner : spawnerList)
                spawner.run2();

        },1,1L);

        Bukkit.getScheduler().runTaskTimerAsynchronously(this,()->{
            for(Spawner spawner : spawnerList)
                spawner.run();

        },1,20L);
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}

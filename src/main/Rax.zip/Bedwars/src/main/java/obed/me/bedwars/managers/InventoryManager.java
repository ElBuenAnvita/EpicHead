package obed.me.bedwars.managers;

public class InventoryManager {


}

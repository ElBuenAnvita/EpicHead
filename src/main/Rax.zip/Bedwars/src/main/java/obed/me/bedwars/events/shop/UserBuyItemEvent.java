package obed.me.bedwars.events.shop;

import lombok.Getter;
import lombok.Setter;
import obed.me.bedwars.objects.game.User;
import obed.me.bedwars.objects.shop.SItem;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@Getter
@Setter
public final class UserBuyItemEvent extends Event implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private boolean cancelled;
    private User user;
    private SItem category;
    private SItem item;
    private obed.me.bedwars.events.shop.Result result;


    public UserBuyItemEvent(User user, SItem category, SItem item, obed.me.bedwars.events.shop.Result result) {
        this.user = user;
        this.category = category;
        this.item = item;
        this.result = result;
    }
    public HandlerList getHandlers(){
        return handlers;
    }
    public static HandlerList getHandlerList() {
        return handlers;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean b) {
        cancelled = b;
    }

}
